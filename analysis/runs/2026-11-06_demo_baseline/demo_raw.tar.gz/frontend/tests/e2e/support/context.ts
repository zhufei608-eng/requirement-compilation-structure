// Compiler-owned Given/observation fixture. When actions go through the browser.
import { test as base, expect } from "@playwright/test";
import type Database from "better-sqlite3";
import { basename, dirname } from "node:path";
import { createDatabaseClient } from "../../../../backend/src/db/client.js";
import { initializeDatabase } from "../../../../backend/src/db/initialize.js";
export { fixturePasswordHash } from "../../../../backend/tests/support/context.js";
export const test = base.extend<{ database: Database.Database; applicationErrors: void }>({
  database: [async ({}, use) => {
    const path = process.env.ARC_E2E_DB_FILE;
    if (!path || basename(path) !== "app.db" || !basename(dirname(path)).startsWith("arc-e2e-"))
      throw new Error("E2E fixtures require the runner-owned temporary database");
    const connection = createDatabaseClient(path);
    try {
      initializeDatabase(connection);
      connection.pragma("foreign_keys = OFF");
      connection.transaction(() => {
        const tables = connection.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all() as { name: string }[];
        for (const table of tables) connection.exec(`DELETE FROM "${table.name.replaceAll('"', '""')}"`);
      })();
      connection.pragma("foreign_keys = ON");
      initializeDatabase(connection);
      await use(connection);
    } finally { connection.close(); }
  }, { auto: true }],
  applicationErrors: [async ({ page, database }, use) => {
    void database;
    const errors: string[] = [];
    page.on("pageerror", error => errors.push("E2E_RUNTIME_ERROR: " + error.message));
    page.on("requestfailed", request => {
      if (new URL(request.url()).pathname.startsWith("/api/")) errors.push("E2E_NETWORK_ERROR: " + request.url());
    });
    await use();
    if (errors.length) throw new Error(errors.join("\n"));
  }, { auto: true }],
});
export { expect };
