import type { Page } from "@playwright/test";
import { test, expect } from "./support/context.js";

async function openRegisterPage(page: Page) {
  await page.goto("/");
  await page.getByTestId("UI-register-link").click();
  await expect(page.getByTestId("UI-register-page")).toBeVisible();
}

async function fillRegistrationForm(page: Page, username: string, email: string) {
  await page.getByTestId("UI-register-nationality").selectOption("China");
  await page.getByTestId("UI-register-name").fill("Smoke Traveler");
  await page.getByTestId("UI-register-passport-number").fill("P12345678");
  await page.getByTestId("UI-register-passport-expiration").fill("2032-05-01");
  await page.getByTestId("UI-register-birth-date").fill("1992-03-04");
  await page.getByTestId("UI-register-gender").getByRole("radio", { name: "Male", exact: true }).check();
  await page.getByTestId("UI-register-username").fill(username);
  await page.getByTestId("UI-register-password").fill("SmokePass!2026");
  await page.getByTestId("UI-register-confirm-password").fill("SmokePass!2026");
  await page.getByTestId("UI-register-email").fill(email);
  await page.getByTestId("UI-register-agreement").check();
}

function watchAccountSubmissions(page: Page) {
  const submissions: string[] = [];
  page.on("request", request => {
    if (request.method() === "POST" && new URL(request.url()).pathname === "/api/accounts") {
      submissions.push(request.url());
    }
  });
  return submissions;
}

test("successful registration signs the traveler in and survives a reload", async ({ page, database }) => {
  const username = "smoke_traveler";

  await openRegisterPage(page);

  const submissions = watchAccountSubmissions(page);
  const responsePromise = page.waitForResponse(
    response => response.request().method() === "POST" && new URL(response.url()).pathname === "/api/accounts"
  );

  await fillRegistrationForm(page, username, "smoke_traveler@example.com");
  await page.getByTestId("UI-next-step").click();

  const response = await responsePromise;
  expect(response.status()).toBe(201);

  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByTestId("UI-username")).toHaveText(username);
  await expect(page.getByTestId("UI-register-link")).toHaveCount(0);
  await expect(page.getByTestId("UI-login-link")).toHaveCount(0);
  expect(submissions).toHaveLength(1);

  const saved = database
    .prepare('SELECT "username", "agreement_consent" FROM "Account" WHERE "username" = ?')
    .get(username) as { username: string; agreement_consent: number } | undefined;
  expect(saved).toBeTruthy();
  expect(saved?.agreement_consent).toBe(1);

  await page.reload();
  await expect(page.getByTestId("UI-username")).toHaveText(username);
  await expect(page.getByTestId("UI-register-link")).toHaveCount(0);
  await expect(page.getByTestId("UI-login-link")).toHaveCount(0);
});

test("duplicate username shows an alert and creates neither account nor session", async ({ page, database }) => {
  const countAccounts = () =>
    (database.prepare('SELECT COUNT(*) AS n FROM "Account"').get() as { n: number }).n;
  const countSessions = () =>
    (database.prepare('SELECT COUNT(*) AS n FROM "Session"').get() as { n: number }).n;

  const accountsBefore = countAccounts();
  const sessionsBefore = countSessions();

  await openRegisterPage(page);

  const submissions = watchAccountSubmissions(page);
  const responsePromise = page.waitForResponse(
    response => response.request().method() === "POST" && new URL(response.url()).pathname === "/api/accounts"
  );

  await fillRegistrationForm(page, "taken_traveler", "other_traveler@example.com");
  await page.getByTestId("UI-next-step").click();

  const response = await responsePromise;
  expect(response.status()).toBe(409);
  expect(submissions).toHaveLength(1);

  await expect(page).toHaveURL(/\/register$/);
  await expect(page.getByTestId("UI-register-error")).toBeVisible();
  await expect(page.getByRole("alert")).toBeVisible();

  expect(countAccounts()).toBe(accountsBefore);
  expect(countSessions()).toBe(sessionsBefore);
  const taken = database
    .prepare('SELECT COUNT(*) AS n FROM "Account" WHERE "username" = ?')
    .get("taken_traveler") as { n: number };
  expect(taken.n).toBe(1);

  await page.goto("/");
  await expect(page.getByTestId("UI-register-link")).toBeVisible();
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-username")).toHaveCount(0);

  await page.reload();
  await expect(page.getByTestId("UI-register-link")).toBeVisible();
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-username")).toHaveCount(0);
});
