import { test, expect } from "./support/context.js";

const USERNAME = "taken_traveler";
const CORRECT_PASSWORD = "TakenSmoke!2026";
const WRONG_PASSWORD = "WrongSmoke!2026";

function isSessionPost(url: string, method: string): boolean {
  return method === "POST" && new URL(url).pathname === "/api/sessions";
}

function sessionCount(database: { prepare: (sql: string) => { get: () => unknown } }): number {
  const row = database.prepare('SELECT COUNT(*) AS value FROM "Session"').get() as { value: number };
  return row.value;
}

test("signs in with existing credentials and stays signed in after refresh", async ({ page, database }) => {
  await page.goto("/");
  await expect(page.getByTestId("UI-login-link")).toBeVisible();

  // Navigate to the login page through the signed-out header link.
  await page.getByTestId("UI-login-link").click();
  await expect(page.getByTestId("UI-login-page")).toBeVisible();

  await page.getByTestId("UI-login-username").fill(USERNAME);
  await page.getByTestId("UI-login-password").fill(CORRECT_PASSWORD);
  await expect(page.getByTestId("UI-login-password")).toHaveAttribute("type", "password");

  const sessionsBefore = sessionCount(database);
  const loginPosts: number[] = [];
  page.on("response", response => {
    if (isSessionPost(response.url(), response.request().method())) loginPosts.push(response.status());
  });

  const loginResponse = page.waitForResponse(response =>
    isSessionPost(response.url(), response.request().method())
  );
  await page.getByTestId("UI-login-submit").click();

  expect((await loginResponse).status()).toBe(200);

  // Home page reflects the resolved session identity.
  await expect(page.getByTestId("UI-username")).toHaveText(USERNAME);
  await expect(page.getByTestId("UI-login-link")).toHaveCount(0);
  await expect(page.getByTestId("UI-register-link")).toHaveCount(0);

  // A single login submission created the session state.
  expect(loginPosts).toEqual([200]);
  expect(sessionCount(database)).toBe(sessionsBefore + 1);

  // Session survives a full page refresh.
  await page.reload();
  await expect(page.getByTestId("UI-username")).toHaveText(USERNAME);
  await expect(page.getByTestId("UI-login-link")).toHaveCount(0);
  await expect(page.getByTestId("UI-register-link")).toHaveCount(0);
});

test("rejects an incorrect password without creating a session", async ({ page, database }) => {
  await page.goto("/login");
  await expect(page.getByTestId("UI-login-page")).toBeVisible();

  await page.getByTestId("UI-login-username").fill(USERNAME);
  await page.getByTestId("UI-login-password").fill(WRONG_PASSWORD);

  const sessionsBefore = sessionCount(database);
  const loginPosts: number[] = [];
  page.on("response", response => {
    if (isSessionPost(response.url(), response.request().method())) loginPosts.push(response.status());
  });

  const loginResponse = page.waitForResponse(response =>
    isSessionPost(response.url(), response.request().method())
  );
  await page.getByTestId("UI-login-submit").click();

  expect((await loginResponse).status()).toBe(401);

  await expect(page.getByRole("alert")).toBeVisible();
  await expect(page.getByTestId("UI-login-page")).toBeVisible();

  expect(loginPosts).toEqual([401]);
  expect(sessionCount(database)).toBe(sessionsBefore);

  // Still signed out on the home page, including after a refresh.
  await page.goto("/");
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-register-link")).toBeVisible();

  await page.reload();
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-register-link")).toBeVisible();
  await expect(page.getByTestId("UI-username")).toHaveCount(0);
});
