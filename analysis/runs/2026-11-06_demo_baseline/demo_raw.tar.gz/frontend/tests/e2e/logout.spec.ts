import type Database from "better-sqlite3";
import { test, expect } from "./support/context.js";

const SESSION_COOKIE = "session";
const SESSION_CREDENTIAL = "taken-traveler-session-credential";
const USERNAME = "taken_traveler";

function countRows(database: Database.Database, table: "Account" | "Session"): number {
  return (database.prepare(`SELECT COUNT(*) AS n FROM "${table}"`).get() as { n: number }).n;
}

function isCurrentSessionRequest(url: string, method: string): boolean {
  return method === "DELETE" && new URL(url).pathname === "/api/session/current";
}

test("logging out clears the session and stays signed out after refresh", async ({ page, database }) => {
  await page.context().addCookies([
    { name: SESSION_COOKIE, value: SESSION_CREDENTIAL, domain: "127.0.0.1", path: "/" },
  ]);

  const accountsBefore = countRows(database, "Account");
  const sessionsBefore = countRows(database, "Session");
  const accountBefore = database
    .prepare('SELECT "username", "password_hash", "agreement_consent" FROM "Account" WHERE "username" = ?')
    .get(USERNAME) as { username: string; password_hash: string; agreement_consent: number } | undefined;
  expect(accountBefore).toBeTruthy();

  await page.goto("/");
  await expect(page.getByTestId("UI-username")).toHaveText(USERNAME);
  const logoutButton = page.getByTestId("UI-logout-button");
  await expect(logoutButton).toBeVisible();
  await expect(page.getByTestId("UI-register-link")).toHaveCount(0);
  await expect(page.getByTestId("UI-login-link")).toHaveCount(0);

  const logoutSubmissions: string[] = [];
  page.on("request", request => {
    if (isCurrentSessionRequest(request.url(), request.method())) logoutSubmissions.push(request.url());
  });
  const logoutResponse = page.waitForResponse(response =>
    isCurrentSessionRequest(response.url(), response.request().method())
  );

  await logoutButton.click();

  const response = await logoutResponse;
  expect(response.status()).toBe(204);

  // The signed-out header appears on the home page and the username and Logout are removed.
  await expect(page).toHaveURL(/\/$/);
  await expect(page.getByTestId("UI-register-link")).toBeVisible();
  await expect(page.getByTestId("UI-register-link")).toHaveAttribute("href", "/register");
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-login-link")).toHaveAttribute("href", "/login");
  await expect(page.getByTestId("UI-username")).toHaveCount(0);
  await expect(page.getByTestId("UI-logout-button")).toHaveCount(0);

  // Exactly one logout submission invalidated the session.
  expect(logoutSubmissions).toHaveLength(1);
  expect(countRows(database, "Session")).toBe(sessionsBefore - 1);
  const remaining = database
    .prepare('SELECT COUNT(*) AS n FROM "Session" WHERE "credential" = ?')
    .get(SESSION_CREDENTIAL) as { n: number };
  expect(remaining.n).toBe(0);

  // Account, traveler details and password hash are preserved.
  expect(countRows(database, "Account")).toBe(accountsBefore);
  const accountAfter = database
    .prepare('SELECT "username", "password_hash", "agreement_consent" FROM "Account" WHERE "username" = ?')
    .get(USERNAME) as { username: string; password_hash: string; agreement_consent: number } | undefined;
  expect(accountAfter?.password_hash).toBe(accountBefore?.password_hash);
  expect(accountAfter?.agreement_consent).toBe(accountBefore?.agreement_consent);

  // Refreshing the home page preserves the signed-out state.
  const refreshSession = page.waitForResponse(response =>
    response.request().method() === "GET" && new URL(response.url()).pathname === "/api/session/current"
  );
  await page.reload();
  const refreshResponse = await refreshSession;
  expect(refreshResponse.status()).toBe(200);
  expect(await refreshResponse.json()).toMatchObject({ authenticated: false, username: null });

  await expect(page.getByTestId("UI-register-link")).toBeVisible();
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-username")).toHaveCount(0);
  await expect(page.getByTestId("UI-logout-button")).toHaveCount(0);
});
