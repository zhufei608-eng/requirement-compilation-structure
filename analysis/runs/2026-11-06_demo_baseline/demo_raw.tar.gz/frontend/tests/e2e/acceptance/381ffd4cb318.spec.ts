import { test, expect } from "../support/context";

// REQ-2 Register: browser-driven acceptance tests.
// Expected behavior is derived from the requirement, not from the implementation.

interface RegistrationDetails {
  nationality?: string;
  name: string;
  passportNumber: string;
  passportExpirationDate: string;
  dateOfBirth: string;
  gender: "Male" | "Female";
  username: string;
  password: string;
  confirmPassword?: string;
  email: string;
}

async function fillRegistrationForm(page: import("@playwright/test").Page, details: RegistrationDetails) {
  const nationality = details.nationality ?? "China";
  await page.getByTestId("UI-register-nationality").selectOption(nationality);
  await page.getByTestId("UI-register-name").fill(details.name);
  await page.getByTestId("UI-register-passport-number").fill(details.passportNumber);
  await page.getByTestId("UI-register-passport-expiration").fill(details.passportExpirationDate);
  await page.getByTestId("UI-register-birth-date").fill(details.dateOfBirth);
  await page.getByRole("radio", { name: details.gender, exact: true }).check();
  await page.getByTestId("UI-register-username").fill(details.username);
  await page.getByTestId("UI-register-password").fill(details.password);
  await page.getByTestId("UI-register-confirm-password").fill(details.confirmPassword ?? details.password);
  await page.getByTestId("UI-register-email").fill(details.email);
  await page.getByTestId("UI-register-agreement").check();
}

function trackRegistrationPosts(page: import("@playwright/test").Page): string[] {
  const posts: string[] = [];
  page.on("request", request => {
    if (request.method() !== "POST") return;
    if (new URL(request.url()).pathname !== "/api/accounts") return;
    posts.push(request.url());
  });
  return posts;
}

const TRAVELER = {
  nationality: "China",
  name: "Ada Traveler",
  passportNumber: "E12345678",
  passportExpirationDate: "2032-06-30",
  dateOfBirth: "1994-03-12",
  gender: "Female" as const,
  email: "ada.traveler@example.com",
};

test("registers a new traveler, signs them in and keeps the session after refresh", async ({ page, database }) => {
  const username = "new_traveler_ada";
  const password = "SecretHash!2026";

  await page.goto("/");
  await page.getByTestId("UI-register-link").click();
  await expect(page).toHaveURL(/\/register\/?$/);

  // Requirement: Nationality defaults to China and offers China; Gender offers Male & Female;
  // password fields conceal typed characters.
  await expect(page.getByTestId("UI-register-nationality")).toHaveValue("China");
  await expect(page.getByTestId("UI-register-nationality").locator('option[value="China"]')).toHaveCount(1);
  await expect(page.getByRole("radio", { name: "Male", exact: true })).toBeVisible();
  await expect(page.getByRole("radio", { name: "Female", exact: true })).toBeVisible();
  await expect(page.getByTestId("UI-register-password")).toHaveAttribute("type", "password");
  await expect(page.getByTestId("UI-register-confirm-password")).toHaveAttribute("type", "password");
  await expect(page.getByTestId("UI-next-step")).toHaveText(/Next step/);

  const before = database.prepare('SELECT COUNT(*) AS n FROM "Account"').get() as { n: number };
  const posts = trackRegistrationPosts(page);

  await fillRegistrationForm(page, { ...TRAVELER, username, password, confirmPassword: password });

  const responsePromise = page.waitForResponse(
    response => response.request().method() === "POST" && new URL(response.url()).pathname === "/api/accounts",
  );
  await page.getByTestId("UI-next-step").click();
  const response = await responsePromise;
  expect(response.status()).toBe(201);

  // One registration submission only.
  expect(posts.length).toBe(1);

  // Redirect to the home page and signed-in display.
  await page.waitForURL(url => url.pathname === "/");
  await expect(page.getByTestId("UI-username")).toHaveText(username);
  await expect(page.getByTestId("UI-register-link")).toBeHidden();
  await expect(page.getByTestId("UI-login-link")).toBeHidden();

  // Persisted business result.
  const after = database.prepare('SELECT COUNT(*) AS n FROM "Account"').get() as { n: number };
  expect(after.n).toBe(before.n + 1);

  const row = database
    .prepare('SELECT * FROM "Account" WHERE "username" = ?')
    .get(username) as Record<string, unknown> | undefined;
  expect(row).toBeTruthy();
  const account = row as Record<string, unknown>;
  expect(account.name).toBe(TRAVELER.name);
  expect(account.nationality).toBe(TRAVELER.nationality);
  expect(account.passport_number).toBe(TRAVELER.passportNumber);
  expect(account.passport_expiration_date).toBe(TRAVELER.passportExpirationDate);
  expect(account.date_of_birth).toBe(TRAVELER.dateOfBirth);
  expect(account.gender).toBe(TRAVELER.gender);
  expect(account.email).toBe(TRAVELER.email);

  // Password hash, not plaintext. Confirm Password must not be a stored column.
  expect(typeof account.password_hash).toBe("string");
  expect(account.password_hash).not.toBe(password);
  expect(String(account.password_hash)).not.toContain(password);
  expect(Object.keys(account).map(key => key.toLowerCase())).not.toContain("confirmpassword");

  // Agreement consent is true.
  const consent = account.agreement_consent;
  expect(consent === 1 || consent === true || consent === "1").toBeTruthy();

  // A session tied to this account was created.
  const session = database
    .prepare('SELECT COUNT(*) AS n FROM "Session" s JOIN "Account" a ON a."id" = s."account_id" WHERE a."username" = ?')
    .get(username) as { n: number };
  expect(session.n).toBeGreaterThanOrEqual(1);

  // Signed in after refresh.
  await page.reload();
  await expect(page.getByTestId("UI-username")).toHaveText(username);
  await expect(page.getByTestId("UI-register-link")).toBeHidden();
  await expect(page.getByTestId("UI-login-link")).toBeHidden();
});

test("rejects a duplicate username without creating an account or a session", async ({ page, database }) => {
  const accountsBefore = database.prepare('SELECT COUNT(*) AS n FROM "Account"').get() as { n: number };
  const sessionsBefore = database.prepare('SELECT COUNT(*) AS n FROM "Session"').get() as { n: number };

  await page.goto("/register");
  await expect(page.getByTestId("UI-register-form")).toBeVisible();

  const posts = trackRegistrationPosts(page);

  await fillRegistrationForm(page, {
    nationality: "China",
    name: "Duplicate Traveler",
    passportNumber: "E98765432",
    passportExpirationDate: "2033-01-15",
    dateOfBirth: "1991-09-01",
    gender: "Male",
    username: "taken_traveler",
    password: "AnotherSecret!2026",
    confirmPassword: "AnotherSecret!2026",
    email: "fresh.duplicate@example.com",
  });

  const responsePromise = page.waitForResponse(
    response => response.request().method() === "POST" && new URL(response.url()).pathname === "/api/accounts",
  );
  await page.getByTestId("UI-next-step").click();
  const response = await responsePromise;
  expect(response.status()).toBe(409);
  expect(posts.length).toBe(1);

  // Error with role=alert is visible.
  const alert = page.getByRole("alert");
  await expect(alert).toBeVisible();

  // No account or session was created; existing rows are unchanged.
  const accountsAfter = database.prepare('SELECT COUNT(*) AS n FROM "Account"').get() as { n: number };
  const sessionsAfter = database.prepare('SELECT COUNT(*) AS n FROM "Session"').get() as { n: number };
  expect(accountsAfter.n).toBe(accountsBefore.n);
  expect(sessionsAfter.n).toBe(sessionsBefore.n);

  const taken = database
    .prepare('SELECT * FROM "Account" WHERE "username" = ?')
    .get("taken_traveler") as Record<string, unknown> | undefined;
  expect(taken).toBeTruthy();
  expect((taken as Record<string, unknown>).email).toBe("taken_traveler@example.com");

  // After refreshing the home page the visitor is still signed out.
  await page.goto("/");
  await expect(page.getByTestId("UI-register-link")).toBeVisible();
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-username")).toBeHidden();
  await page.reload();
  await expect(page.getByTestId("UI-register-link")).toBeVisible();
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-username")).toBeHidden();
});

test("compares usernames by exact value so a differently cased username is unused", async ({ page, database }) => {
  const username = "Taken_Traveler"; // different exact value than taken_traveler

  await page.goto("/register");
  await fillRegistrationForm(page, {
    nationality: "China",
    name: "Case Traveler",
    passportNumber: "E55550001",
    passportExpirationDate: "2031-11-11",
    dateOfBirth: "1990-02-02",
    gender: "Female",
    username,
    password: "CaseSecret!2026",
    confirmPassword: "CaseSecret!2026",
    email: "case.traveler@example.com",
  });

  const responsePromise = page.waitForResponse(
    response => response.request().method() === "POST" && new URL(response.url()).pathname === "/api/accounts",
  );
  await page.getByTestId("UI-next-step").click();
  const response = await responsePromise;
  expect(response.status()).toBe(201);

  await page.waitForURL(url => url.pathname === "/");
  await expect(page.getByTestId("UI-username")).toHaveText(username);

  const row = database
    .prepare('SELECT "id" FROM "Account" WHERE "username" = ?')
    .get(username) as { id: string } | undefined;
  expect(row).toBeTruthy();

  // Existing account untouched.
  const taken = database
    .prepare('SELECT "email" FROM "Account" WHERE "username" = ?')
    .get("taken_traveler") as { email: string } | undefined;
  expect(taken?.email).toBe("taken_traveler@example.com");
});

test("shows the newly registered identity to a second distinct account", async ({ page }) => {
  const firstUser = "first_traveler";
  const secondUser = "second_traveler";

  await page.goto("/register");
  await fillRegistrationForm(page, {
    nationality: "China",
    name: "First Traveler",
    passportNumber: "E11110001",
    passportExpirationDate: "2032-01-01",
    dateOfBirth: "1988-04-04",
    gender: "Male",
    username: firstUser,
    password: "FirstSecret!2026",
    confirmPassword: "FirstSecret!2026",
    email: "first.traveler@example.com",
  });
  await page.getByTestId("UI-next-step").click();
  await page.waitForURL(url => url.pathname === "/");
  await expect(page.getByTestId("UI-username")).toHaveText(firstUser);

  // Register a second, distinct account through the UI.
  await page.goto("/register");
  await fillRegistrationForm(page, {
    nationality: "China",
    name: "Second Traveler",
    passportNumber: "E22220002",
    passportExpirationDate: "2032-02-02",
    dateOfBirth: "1989-05-05",
    gender: "Female",
    username: secondUser,
    password: "SecondSecret!2026",
    confirmPassword: "SecondSecret!2026",
    email: "second.traveler@example.com",
  });
  await page.getByTestId("UI-next-step").click();
  await page.waitForURL(url => url.pathname === "/");

  // The current session must reflect the second account, not the first.
  await expect(page.getByTestId("UI-username")).toHaveText(secondUser);
  await page.reload();
  await expect(page.getByTestId("UI-username")).toHaveText(secondUser);
  await expect(page.getByTestId("UI-login-link")).toBeHidden();
});
