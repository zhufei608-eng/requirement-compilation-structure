import { test, expect, fixturePasswordHash } from "../support/context.js";

const TRAVELER = "taken_traveler";
const TRAVELER_PASSWORD = "TakenSmoke!2026";

const OTHER_TRAVELER = "second_traveler";
const OTHER_PASSWORD = "SecondSmoke!2026";

interface AccountRow {
  id: string;
  username: string;
  nationality: string;
  name: string;
  passport_number: string;
  passport_expiration_date: string;
  date_of_birth: string;
  gender: string;
  email: string;
  password_hash: string;
  agreement_consent: number;
}

function insertAccount(
  database: import("better-sqlite3").Database,
  username: string,
  password: string,
): string {
  const id = `11111111-2222-4333-8444-${username === TRAVELER ? "555555555551" : "555555555552"}`;
  database
    .prepare(
      `INSERT INTO "Account" ("id", "username", "nationality", "name", "passport_number", "passport_expiration_date", "date_of_birth", "gender", "email", "password_hash", "agreement_consent") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      id,
      username,
      "China",
      "Second Traveler",
      "P00000002",
      "2031-01-01",
      "1991-01-01",
      "Female",
      `${username}@example.com`,
      fixturePasswordHash(password),
      1,
    );
  return id;
}

function accountRows(database: import("better-sqlite3").Database): AccountRow[] {
  return database.prepare('SELECT * FROM "Account" ORDER BY "username"').all() as AccountRow[];
}

function sessionCount(database: import("better-sqlite3").Database): number {
  return (database.prepare('SELECT COUNT(*) AS count FROM "Session"').get() as { count: number }).count;
}

async function fillAndSubmitLogin(
  page: import("@playwright/test").Page,
  username: string,
  password: string,
): Promise<void> {
  await page.getByTestId("UI-login-username").fill(username);
  await page.getByTestId("UI-login-password").fill(password);
  await page.getByTestId("UI-login-submit").click();
}

async function openLoginFromHome(page: import("@playwright/test").Page): Promise<void> {
  await page.goto("/");
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await page.getByTestId("UI-login-link").click();
  await expect(page).toHaveURL(/\/login$/);
  await expect(page.getByPlaceholder("Email/Username/Mobile number")).toBeVisible();
  await expect(page.getByPlaceholder("Password")).toBeVisible();
  await expect(page.getByRole("button", { name: "LOGIN" })).toBeVisible();
}

test.describe("REQ-3 Login", () => {
  test("logs in an existing account, returns home, hides Register/Login and survives refresh", async ({
    page,
    database,
  }) => {
    const beforeAccounts = accountRows(database);
    expect(beforeAccounts.filter(row => row.username === TRAVELER).length).toBe(1);

    await openLoginFromHome(page);

    // Observe the single login operation before triggering it.
    const loginResponses: import("@playwright/test").Response[] = [];
    const loginRequests: string[] = [];
    page.on("request", request => {
      if (new URL(request.url()).pathname === "/api/sessions") loginRequests.push(request.method());
    });
    page.on("response", response => {
      if (new URL(response.url()).pathname === "/api/sessions" && response.request().method() === "POST") {
        loginResponses.push(response);
      }
    });

    await fillAndSubmitLogin(page, TRAVELER, TRAVELER_PASSWORD);

    await expect(page).toHaveURL(/\/$/);
    await expect(page.getByTestId("UI-username")).toHaveText(TRAVELER);
    await expect(page.getByTestId("UI-username")).toBeVisible();
    await expect(page.getByTestId("UI-register-link")).toBeHidden();
    await expect(page.getByTestId("UI-login-link")).toBeHidden();
    await expect(page.getByTestId("UI-logout-button")).toBeVisible();

    // Exactly one login operation was submitted.
    expect(loginRequests.filter(method => method === "POST")).toHaveLength(1);
    expect(loginResponses).toHaveLength(1);
    expect(loginResponses[0].status()).toBe(200);

    // A session was created for the correct account; account data was not changed.
    const account = accountRows(database).filter(row => row.username === TRAVELER);
    expect(account).toHaveLength(1);
    const sessions = database
      .prepare('SELECT * FROM "Session" WHERE "account_id" = ?')
      .all(account[0].id) as { account_id: string }[];
    expect(sessions.length).toBeGreaterThanOrEqual(1);
    expect(accountRows(database)).toEqual(beforeAccounts);

    // The signed-in identity persists after a full page refresh.
    await page.reload();
    await expect(page.getByTestId("UI-username")).toHaveText(TRAVELER);
    await expect(page.getByTestId("UI-register-link")).toBeHidden();
    await expect(page.getByTestId("UI-login-link")).toBeHidden();
  });

  test("rejects a wrong password with an alert, creates no session and leaves accounts unchanged", async ({
    page,
    database,
  }) => {
    const beforeAccounts = accountRows(database);
    expect(beforeAccounts.filter(row => row.username === TRAVELER).length).toBe(1);
    const sessionsBefore = sessionCount(database);

    await openLoginFromHome(page);
    await fillAndSubmitLogin(page, TRAVELER, "WrongSmoke!2026");

    const alert = page.getByRole("alert");
    await expect(alert).toBeVisible();
    await expect(alert).not.toHaveText(/^\s*$/);
    await expect(alert).toContainText(/invalid|incorrect/i);

    // Still on the login page; no session was created or persisted.
    await expect(page).toHaveURL(/\/login$/);
    expect(sessionCount(database)).toBe(sessionsBefore);
    expect(accountRows(database)).toEqual(beforeAccounts);
    const cookies = await page.context().cookies();
    expect(cookies.filter(cookie => cookie.name === "session" && cookie.value.length > 0)).toHaveLength(0);

    // Visiting home still shows the signed-out navigation after a refresh.
    await page.goto("/");
    await page.reload();
    await expect(page.getByTestId("UI-register-link")).toBeVisible();
    await expect(page.getByTestId("UI-login-link")).toBeVisible();
    await expect(page.getByTestId("UI-username")).toBeHidden();
  });

  test("shows the identity of the account that actually logged in, not another account", async ({
    page,
    database,
  }) => {
    // Two distinct identities exist; only the one whose credentials were entered may be shown.
    insertAccount(database, OTHER_TRAVELER, OTHER_PASSWORD);

    await openLoginFromHome(page);
    await fillAndSubmitLogin(page, OTHER_TRAVELER, OTHER_PASSWORD);

    await expect(page).toHaveURL(/\/$/);
    const displayed = page.getByTestId("UI-username");
    await expect(displayed).toBeVisible();
    await expect(displayed).toHaveText(OTHER_TRAVELER);
    await expect(displayed).not.toHaveText(TRAVELER);

    // The session that was created belongs to the account whose password matched.
    const other = database.prepare('SELECT * FROM "Account" WHERE "username" = ?').get(OTHER_TRAVELER) as
      | AccountRow
      | undefined;
    expect(other).toBeTruthy();
    const sessions = database
      .prepare('SELECT * FROM "Session" WHERE "account_id" = ?')
      .all(other!.id) as { account_id: string }[];
    expect(sessions.length).toBeGreaterThanOrEqual(1);

    await page.reload();
    await expect(page.getByTestId("UI-username")).toHaveText(OTHER_TRAVELER);
  });
});
