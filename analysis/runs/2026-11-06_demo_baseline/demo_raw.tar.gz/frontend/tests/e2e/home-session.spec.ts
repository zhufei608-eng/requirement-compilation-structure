import type Database from "better-sqlite3";
import { test, expect } from "./support/context.js";

const SESSION_COOKIE = "session";
const SESSION_CREDENTIAL = "taken-traveler-session-credential";

function countRows(database: Database.Database, table: "Account" | "Session"): number {
  return (database.prepare(`SELECT COUNT(*) AS n FROM "${table}"`).get() as { n: number }).n;
}

function waitForCurrentSession(page: import("@playwright/test").Page) {
  return page.waitForResponse(
    (response) => new URL(response.url()).pathname === "/api/session/current" && response.request().method() === "GET"
  );
}

test("homepage restores the current user's display from an existing session", async ({ page, database }) => {
  await page.context().addCookies([
    { name: SESSION_COOKIE, value: SESSION_CREDENTIAL, domain: "127.0.0.1", path: "/" },
  ]);

  const accountsBefore = countRows(database, "Account");
  const sessionsBefore = countRows(database, "Session");

  const sessionResponse = waitForCurrentSession(page);
  await page.goto("/");
  const response = await sessionResponse;
  expect(response.status()).toBe(200);

  await expect(page.getByTestId("UI-username")).toHaveText("taken_traveler");
  await expect(page.getByTestId("UI-register-link")).toHaveCount(0);
  await expect(page.getByTestId("UI-login-link")).toHaveCount(0);

  // Session resolution is read-only: no account or session records are created or changed.
  expect(countRows(database, "Account")).toBe(accountsBefore);
  expect(countRows(database, "Session")).toBe(sessionsBefore);
});

test("signed-out homepage shows authentication links and no username", async ({ page, database }) => {
  const accountsBefore = countRows(database, "Account");
  const sessionsBefore = countRows(database, "Session");

  const sessionResponse = waitForCurrentSession(page);
  await page.goto("/");
  const response = await sessionResponse;
  expect(response.status()).toBe(200);
  expect(await response.json()).toMatchObject({ authenticated: false, username: null });

  const register = page.getByTestId("UI-register-link");
  const login = page.getByTestId("UI-login-link");
  await expect(register).toBeVisible();
  await expect(register).toHaveAttribute("href", "/register");
  await expect(login).toBeVisible();
  await expect(login).toHaveAttribute("href", "/login");
  await expect(page.getByTestId("UI-username")).toHaveCount(0);

  // Opening the homepage creates no account or session.
  expect(countRows(database, "Account")).toBe(accountsBefore);
  expect(countRows(database, "Session")).toBe(sessionsBefore);
});
