// Compiler-owned presence tests. Display values belong to this suite only.
import { test, expect } from "@playwright/test";

test("registration / display 1 / UI element existence", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.addInitScript(testData => { (window as unknown as { __ARC_UI_TEST_DATA__: unknown }).__ARC_UI_TEST_DATA__ = testData; }, {"page": "registration", "data": {"registration.nationality": "", "registration.name": "", "registration.passportNumber": "", "registration.passportExpirationDate": "", "registration.dateOfBirth": "", "registration.gender": "", "registration.username": "", "registration.password": "", "registration.confirmPassword": "", "registration.email": "", "registration.agreed": false, "registration.errorMessage": "", "registration.hasError": false}});
  await page.goto("/register");
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
  try {
  await expect(page.getByTestId("UI-register-page")).toBeVisible();
  await expect(page.getByTestId("UI-register-breadcrumb")).toBeVisible();
  await expect(page.getByTestId("UI-register-form")).toBeVisible();
  await expect(page.getByTestId("UI-register-nationality")).toBeVisible();
  await expect(page.getByTestId("UI-register-name")).toBeVisible();
  await expect(page.getByTestId("UI-register-passport-rules-link")).toBeVisible();
  await expect(page.getByTestId("UI-register-passport-number")).toBeVisible();
  await expect(page.getByTestId("UI-register-passport-expiration")).toBeVisible();
  await expect(page.getByTestId("UI-register-birth-date")).toBeVisible();
  await expect(page.getByTestId("UI-register-gender")).toBeVisible();
  await expect(page.getByTestId("UI-register-username")).toBeVisible();
  await expect(page.getByTestId("UI-register-password")).toBeVisible();
  await expect(page.getByTestId("UI-register-confirm-password")).toBeVisible();
  await expect(page.getByTestId("UI-register-email")).toBeVisible();
  await expect(page.getByTestId("UI-register-agreement")).toBeVisible();
  await expect(page.getByTestId("UI-next-step")).toBeVisible();
  await expect(page.getByTestId("UI-register-error")).not.toBeVisible();
  await expect.poll(() => page.evaluate(({ pageId, keys }) => {
    const state = (window as unknown as { __ARC_UI_DATA__?: { page: string; data: Record<string, unknown> } }).__ARC_UI_DATA__;
    return state?.page === pageId && keys.every(key => Object.prototype.hasOwnProperty.call(state.data, key));
  }, {"pageId": "registration", "keys": ["registration.agreed", "registration.confirmPassword", "registration.dateOfBirth", "registration.email", "registration.errorMessage", "registration.gender", "registration.hasError", "registration.name", "registration.nationality", "registration.passportExpirationDate", "registration.passportNumber", "registration.password", "registration.username"]})).toBe(true);
  } catch (error) {
    if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
    throw error;
  }
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
});

test("registration / display 2 / UI element existence", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.addInitScript(testData => { (window as unknown as { __ARC_UI_TEST_DATA__: unknown }).__ARC_UI_TEST_DATA__ = testData; }, {"page": "registration", "data": {"registration.nationality": "", "registration.name": "", "registration.passportNumber": "", "registration.passportExpirationDate": "", "registration.dateOfBirth": "", "registration.gender": "", "registration.username": "", "registration.password": "", "registration.confirmPassword": "", "registration.email": "", "registration.agreed": false, "registration.errorMessage": "", "registration.hasError": true}});
  await page.goto("/register");
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
  try {
  await expect(page.getByTestId("UI-register-page")).toBeVisible();
  await expect(page.getByTestId("UI-register-breadcrumb")).toBeVisible();
  await expect(page.getByTestId("UI-register-form")).toBeVisible();
  await expect(page.getByTestId("UI-register-nationality")).toBeVisible();
  await expect(page.getByTestId("UI-register-name")).toBeVisible();
  await expect(page.getByTestId("UI-register-passport-rules-link")).toBeVisible();
  await expect(page.getByTestId("UI-register-passport-number")).toBeVisible();
  await expect(page.getByTestId("UI-register-passport-expiration")).toBeVisible();
  await expect(page.getByTestId("UI-register-birth-date")).toBeVisible();
  await expect(page.getByTestId("UI-register-gender")).toBeVisible();
  await expect(page.getByTestId("UI-register-username")).toBeVisible();
  await expect(page.getByTestId("UI-register-password")).toBeVisible();
  await expect(page.getByTestId("UI-register-confirm-password")).toBeVisible();
  await expect(page.getByTestId("UI-register-email")).toBeVisible();
  await expect(page.getByTestId("UI-register-agreement")).toBeVisible();
  await expect(page.getByTestId("UI-next-step")).toBeVisible();
  await expect(page.getByTestId("UI-register-error")).toBeVisible();
  await expect.poll(() => page.evaluate(({ pageId, keys }) => {
    const state = (window as unknown as { __ARC_UI_DATA__?: { page: string; data: Record<string, unknown> } }).__ARC_UI_DATA__;
    return state?.page === pageId && keys.every(key => Object.prototype.hasOwnProperty.call(state.data, key));
  }, {"pageId": "registration", "keys": ["registration.agreed", "registration.confirmPassword", "registration.dateOfBirth", "registration.email", "registration.errorMessage", "registration.gender", "registration.hasError", "registration.name", "registration.nationality", "registration.passportExpirationDate", "registration.passportNumber", "registration.password", "registration.username"]})).toBe(true);
  } catch (error) {
    if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
    throw error;
  }
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
});
