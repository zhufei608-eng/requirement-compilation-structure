// Compiler-owned presence tests. Display values belong to this suite only.
import { test, expect } from "@playwright/test";

test("login / display 1 / UI element existence", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.addInitScript(testData => { (window as unknown as { __ARC_UI_TEST_DATA__: unknown }).__ARC_UI_TEST_DATA__ = testData; }, {"page": "login", "data": {"login.username": "", "login.password": "", "login.errorMessage": "", "login.hasError": false}});
  await page.goto("/login");
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
  try {
  await expect(page.getByTestId("UI-login-page")).toBeVisible();
  await expect(page.getByTestId("UI-login-title")).toBeVisible();
  await expect(page.getByTestId("UI-login-username")).toBeVisible();
  await expect(page.getByTestId("UI-login-password")).toBeVisible();
  await expect(page.getByTestId("UI-login-forgot")).toBeVisible();
  await expect(page.getByTestId("UI-login-submit")).toBeVisible();
  await expect(page.getByTestId("UI-login-error")).not.toBeVisible();
  await expect(page.getByTestId("UI-login-register-prompt")).toBeVisible();
  await expect(page.getByTestId("UI-login-register-link")).toBeVisible();
  await expect.poll(() => page.evaluate(({ pageId, keys }) => {
    const state = (window as unknown as { __ARC_UI_DATA__?: { page: string; data: Record<string, unknown> } }).__ARC_UI_DATA__;
    return state?.page === pageId && keys.every(key => Object.prototype.hasOwnProperty.call(state.data, key));
  }, {"pageId": "login", "keys": ["login.errorMessage", "login.hasError", "login.password", "login.username"]})).toBe(true);
  } catch (error) {
    if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
    throw error;
  }
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
});

test("login / display 2 / UI element existence", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.addInitScript(testData => { (window as unknown as { __ARC_UI_TEST_DATA__: unknown }).__ARC_UI_TEST_DATA__ = testData; }, {"page": "login", "data": {"login.username": "", "login.password": "", "login.errorMessage": "", "login.hasError": true}});
  await page.goto("/login");
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
  try {
  await expect(page.getByTestId("UI-login-page")).toBeVisible();
  await expect(page.getByTestId("UI-login-title")).toBeVisible();
  await expect(page.getByTestId("UI-login-username")).toBeVisible();
  await expect(page.getByTestId("UI-login-password")).toBeVisible();
  await expect(page.getByTestId("UI-login-forgot")).toBeVisible();
  await expect(page.getByTestId("UI-login-submit")).toBeVisible();
  await expect(page.getByTestId("UI-login-error")).toBeVisible();
  await expect(page.getByTestId("UI-login-register-prompt")).toBeVisible();
  await expect(page.getByTestId("UI-login-register-link")).toBeVisible();
  await expect.poll(() => page.evaluate(({ pageId, keys }) => {
    const state = (window as unknown as { __ARC_UI_DATA__?: { page: string; data: Record<string, unknown> } }).__ARC_UI_DATA__;
    return state?.page === pageId && keys.every(key => Object.prototype.hasOwnProperty.call(state.data, key));
  }, {"pageId": "login", "keys": ["login.errorMessage", "login.hasError", "login.password", "login.username"]})).toBe(true);
  } catch (error) {
    if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
    throw error;
  }
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
});
