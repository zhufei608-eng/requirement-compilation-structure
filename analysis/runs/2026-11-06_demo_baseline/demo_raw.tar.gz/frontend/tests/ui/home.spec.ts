// Compiler-owned presence tests. Display values belong to this suite only.
import { test, expect } from "@playwright/test";

test("home / display 1 / UI element existence", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.addInitScript(testData => { (window as unknown as { __ARC_UI_TEST_DATA__: unknown }).__ARC_UI_TEST_DATA__ = testData; }, {"page": "home", "data": {"session.status": "", "session.username": ""}});
  await page.goto("/");
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
  try {
  await expect(page.getByTestId("UI-home")).toBeVisible();
  await expect(page.getByTestId("UI-brand")).toBeVisible();
  await expect(page.getByTestId("UI-register-link")).not.toBeVisible();
  await expect(page.getByTestId("UI-login-link")).not.toBeVisible();
  await expect(page.getByTestId("UI-username")).not.toBeVisible();
  await expect(page.getByTestId("UI-logout-button")).not.toBeVisible();
  await expect.poll(() => page.evaluate(({ pageId, keys }) => {
    const state = (window as unknown as { __ARC_UI_DATA__?: { page: string; data: Record<string, unknown> } }).__ARC_UI_DATA__;
    return state?.page === pageId && keys.every(key => Object.prototype.hasOwnProperty.call(state.data, key));
  }, {"pageId": "home", "keys": ["session.status", "session.username"]})).toBe(true);
  } catch (error) {
    if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
    throw error;
  }
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
});

test("home / display 2 / UI element existence", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.addInitScript(testData => { (window as unknown as { __ARC_UI_TEST_DATA__: unknown }).__ARC_UI_TEST_DATA__ = testData; }, {"page": "home", "data": {"session.status": "signed_out", "session.username": ""}});
  await page.goto("/");
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
  try {
  await expect(page.getByTestId("UI-home")).toBeVisible();
  await expect(page.getByTestId("UI-brand")).toBeVisible();
  await expect(page.getByTestId("UI-register-link")).toBeVisible();
  await expect(page.getByTestId("UI-login-link")).toBeVisible();
  await expect(page.getByTestId("UI-username")).not.toBeVisible();
  await expect(page.getByTestId("UI-logout-button")).not.toBeVisible();
  await expect.poll(() => page.evaluate(({ pageId, keys }) => {
    const state = (window as unknown as { __ARC_UI_DATA__?: { page: string; data: Record<string, unknown> } }).__ARC_UI_DATA__;
    return state?.page === pageId && keys.every(key => Object.prototype.hasOwnProperty.call(state.data, key));
  }, {"pageId": "home", "keys": ["session.status", "session.username"]})).toBe(true);
  } catch (error) {
    if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
    throw error;
  }
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
});

test("home / display 3 / UI element existence", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", error => runtimeErrors.push(error.message));
  await page.addInitScript(testData => { (window as unknown as { __ARC_UI_TEST_DATA__: unknown }).__ARC_UI_TEST_DATA__ = testData; }, {"page": "home", "data": {"session.status": "authenticated", "session.username": ""}});
  await page.goto("/");
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
  try {
  await expect(page.getByTestId("UI-home")).toBeVisible();
  await expect(page.getByTestId("UI-brand")).toBeVisible();
  await expect(page.getByTestId("UI-register-link")).not.toBeVisible();
  await expect(page.getByTestId("UI-login-link")).not.toBeVisible();
  await expect(page.getByTestId("UI-username")).toBeVisible();
  await expect(page.getByTestId("UI-logout-button")).toBeVisible();
  await expect.poll(() => page.evaluate(({ pageId, keys }) => {
    const state = (window as unknown as { __ARC_UI_DATA__?: { page: string; data: Record<string, unknown> } }).__ARC_UI_DATA__;
    return state?.page === pageId && keys.every(key => Object.prototype.hasOwnProperty.call(state.data, key));
  }, {"pageId": "home", "keys": ["session.status", "session.username"]})).toBe(true);
  } catch (error) {
    if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
    throw error;
  }
  if (runtimeErrors.length) throw new Error("UI_RUNTIME_ERROR: " + runtimeErrors.join("\n"));
});
