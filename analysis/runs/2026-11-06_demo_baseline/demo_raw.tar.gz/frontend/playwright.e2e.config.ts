import { defineConfig } from "@playwright/test";
const frontendPort = process.env.ARC_E2E_FRONTEND_PORT;
const backendPort = process.env.ARC_E2E_BACKEND_PORT;
const database = process.env.ARC_E2E_DB_FILE;
if (!frontendPort || !backendPort || !database) throw new Error("Use npm run test:e2e or the step 10 runner");
export default defineConfig({
  testDir: "./tests/e2e", outputDir: "./test-results/e2e", workers: 1,
  fullyParallel: false, retries: 0, forbidOnly: true,
  timeout: 30000, expect: { timeout: 5000 }, reporter: "json",
  use: { baseURL: `http://127.0.0.1:${frontendPort}`, browserName: "chromium", headless: true,
    trace: "retain-on-failure", screenshot: "only-on-failure" },
  webServer: [
    { command: "node --import tsx ../backend/src/server.ts",
      url: `http://127.0.0.1:${backendPort}/api/health`, reuseExistingServer: false, timeout: 600000,
      ...(process.platform === "win32" ? {} : { gracefulShutdown: { signal: "SIGTERM" as const, timeout: 3000 } }),
      env: { PORT: backendPort, DATABASE_URL: database } },
    { command: `node ../node_modules/vite/bin/vite.js --config vite.e2e.config.ts --host 127.0.0.1 --port ${frontendPort} --strictPort`,
      url: `http://127.0.0.1:${frontendPort}`, reuseExistingServer: false, timeout: 600000,
      ...(process.platform === "win32" ? {} : { gracefulShutdown: { signal: "SIGTERM" as const, timeout: 3000 } }),
      env: { ARC_BACKEND_URL: `http://127.0.0.1:${backendPort}` } },
  ],
});
