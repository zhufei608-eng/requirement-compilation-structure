import { useEffect, useState } from "react";
import { HomePage } from "./pages/Home";
import { LoginPage } from "./pages/Login";
import { RegisterPage } from "./pages/Register";

function usePathname(): string {
  const [pathname, setPathname] = useState(() => window.location.pathname);

  useEffect(() => {
    const onPopState = () => setPathname(window.location.pathname);
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  return pathname;
}

export function App() {
  const pathname = usePathname();

  if (pathname.replace(/\/+$/, "") === "/register") {
    return <RegisterPage />;
  }

  if (pathname.replace(/\/+$/, "") === "/login") {
    return <LoginPage />;
  }

  return <HomePage />;
}
