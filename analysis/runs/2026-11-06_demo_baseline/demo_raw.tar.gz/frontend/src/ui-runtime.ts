// Presentation-test adapter only; application behavior is implemented by the model.

declare global {
  interface Window {
    __ARC_UI_TEST_DATA__?: { page: string; data: Record<string, unknown> };
    __ARC_UI_DATA__?: { page: string; data: Readonly<Record<string, unknown>> };
  }
}

export function isPresentationTest(page: string): boolean {
  const development = (import.meta as ImportMeta & { env: { DEV: boolean } }).env.DEV;
  return development && window.__ARC_UI_TEST_DATA__?.page === page;
}

export function presentationData(page: string, state: Record<string, unknown>) {
  const development = (import.meta as ImportMeta & { env: { DEV: boolean } }).env.DEV;
  const testData = development ? window.__ARC_UI_TEST_DATA__ : undefined;
  if (development) window.__ARC_UI_DATA__ = { page, data: state };
  return testData?.page === page ? { ...state, ...testData.data } : state;
}
