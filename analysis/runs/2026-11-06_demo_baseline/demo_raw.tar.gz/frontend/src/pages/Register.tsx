import { FormEvent, useState } from "react";
import { presentationData } from "../ui-runtime";

const NATIONALITY_OPTIONS = ["China", "United States", "United Kingdom", "Japan", "Germany", "France"];

interface RegistrationFormState {
  nationality: string;
  name: string;
  passportNumber: string;
  passportExpirationDate: string;
  dateOfBirth: string;
  gender: string;
  username: string;
  password: string;
  confirmPassword: string;
  email: string;
  agreed: boolean;
}

const INITIAL_FORM: RegistrationFormState = {
  nationality: "China",
  name: "",
  passportNumber: "",
  passportExpirationDate: "",
  dateOfBirth: "",
  gender: "",
  username: "",
  password: "",
  confirmPassword: "",
  email: "",
  agreed: false,
};

const inputClass =
  "w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-600 focus:ring-1 focus:ring-blue-600";

export function RegisterPage() {
  const [form, setForm] = useState<RegistrationFormState>(INITIAL_FORM);
  const [errorMessage, setErrorMessage] = useState("");
  const [hasError, setHasError] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const data = presentationData("registration", {
    "registration.nationality": form.nationality,
    "registration.name": form.name,
    "registration.passportNumber": form.passportNumber,
    "registration.passportExpirationDate": form.passportExpirationDate,
    "registration.dateOfBirth": form.dateOfBirth,
    "registration.gender": form.gender,
    "registration.username": form.username,
    "registration.password": form.password,
    "registration.confirmPassword": form.confirmPassword,
    "registration.email": form.email,
    "registration.agreed": form.agreed,
    "registration.errorMessage": errorMessage,
    "registration.hasError": hasError,
  });

  const readString = (key: string): string => {
    const value = data[key];
    return typeof value === "string" ? value : "";
  };
  const readBoolean = (key: string): boolean => data[key] === true;

  const nationality = readString("registration.nationality");
  const name = readString("registration.name");
  const passportNumber = readString("registration.passportNumber");
  const passportExpirationDate = readString("registration.passportExpirationDate");
  const dateOfBirth = readString("registration.dateOfBirth");
  const gender = readString("registration.gender");
  const username = readString("registration.username");
  const password = readString("registration.password");
  const confirmPassword = readString("registration.confirmPassword");
  const email = readString("registration.email");
  const agreed = readBoolean("registration.agreed");
  const failureMessage = readString("registration.errorMessage");
  const errorVisible = readBoolean("registration.hasError");

  const update = <K extends keyof RegistrationFormState>(key: K, value: RegistrationFormState[K]) => {
    setForm(previous => ({ ...previous, [key]: value }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    try {
      const response = await fetch("/api/accounts", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          nationality: form.nationality,
          name: form.name,
          passportNumber: form.passportNumber,
          passportExpirationDate: form.passportExpirationDate,
          dateOfBirth: form.dateOfBirth,
          gender: form.gender,
          username: form.username,
          password: form.password,
          confirmPassword: form.confirmPassword,
          email: form.email,
          agreementConsent: form.agreed,
        }),
      });

      if (response.status === 201) {
        setHasError(false);
        setErrorMessage("");
        window.location.assign("/");
        return;
      }

      let message = "";
      try {
        const payload: unknown = await response.json();
        if (typeof payload === "object" && payload !== null) {
          const error = (payload as Record<string, unknown>).error;
          if (typeof error === "object" && error !== null) {
            const candidate = (error as Record<string, unknown>).message;
            if (typeof candidate === "string") message = candidate;
          }
        }
      } catch {
        message = "";
      }
      setHasError(true);
      setErrorMessage(message.length > 0 ? message : "Registration failed. Please try again.");
    } catch {
      setHasError(true);
      setErrorMessage("Registration failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div data-testid="UI-register-page" className="min-h-screen bg-white text-slate-800">
      <header className="border-b border-slate-100 bg-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-4">
          <div className="flex items-center gap-3">
            <span
              aria-hidden="true"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-red-700 text-lg font-bold text-white"
            >
              中
            </span>
            <div className="leading-tight">
              <div className="text-xl font-bold tracking-tight text-slate-900">中国铁路12306</div>
              <div className="text-[11px] font-medium uppercase tracking-[0.18em] text-slate-500">
                12306 CHINA RAILWAY
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-sm">
            <a href="/login" className="font-medium text-slate-700 transition-colors hover:text-blue-700">
              Login
            </a>
            <a href="/register" className="font-medium text-slate-700 transition-colors hover:text-blue-700">
              Register
            </a>
            <span className="hidden items-center gap-1 text-slate-600 sm:inline-flex">
              My 12306 <span aria-hidden="true" className="text-[10px]">▼</span>
            </span>
            <span className="hidden items-center gap-1 text-slate-600 sm:inline-flex">
              简体中文 <span aria-hidden="true" className="text-[10px]">▼</span>
            </span>
            <span className="hidden items-center gap-1 text-slate-600 md:inline-flex">
              <span aria-hidden="true">☎</span> Contact us
            </span>
          </div>
        </div>
      </header>

      <nav aria-label="Main navigation" className="bg-blue-700 text-white">
        <div className="mx-auto flex max-w-7xl items-center gap-8 px-6 py-3 text-sm font-medium">
          <a href="/" className="font-semibold text-white no-underline">
            Home
          </a>
          <span className="flex items-center gap-1">
            Booking <span aria-hidden="true" className="text-[10px]">▼</span>
          </span>
          <span className="flex items-center gap-1">
            Travel guides <span aria-hidden="true" className="text-[10px]">▼</span>
          </span>
        </div>
      </nav>

      <main className="mx-auto max-w-5xl px-6 py-8">
        <p data-testid="UI-register-breadcrumb" className="text-xs text-slate-500">
          Current location: HOME &gt; Create an account
        </p>

        <form
          data-testid="UI-register-form"
          onSubmit={handleSubmit}
          noValidate
          className="mt-4 rounded-lg border border-slate-200 bg-white p-8 shadow-sm"
        >
          <div className="space-y-5">
            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-nationality"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Nationality
              </label>
              <div className="md:flex-1">
                <select
                  id="register-nationality"
                  data-testid="UI-register-nationality"
                  value={nationality}
                  onChange={event => update("nationality", event.target.value)}
                  className={inputClass}
                >
                  <option value="">Please select</option>
                  {NATIONALITY_OPTIONS.map(option => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
                <p className="mt-1 text-xs text-orange-600">
                  At present, only foreign passports are accepted for registration.
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-name"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Name
              </label>
              <div className="md:flex-1">
                <input
                  id="register-name"
                  data-testid="UI-register-name"
                  type="text"
                  value={name}
                  onChange={event => update("name", event.target.value)}
                  className={inputClass}
                />
                <a
                  data-testid="UI-register-passport-rules-link"
                  href="#"
                  className="mt-1 inline-block text-xs text-blue-700 hover:underline"
                >
                  Check the rules for filling out passport information
                </a>
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-passport-number"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Passport number
              </label>
              <div className="md:flex-1">
                <input
                  id="register-passport-number"
                  data-testid="UI-register-passport-number"
                  type="text"
                  value={passportNumber}
                  onChange={event => update("passportNumber", event.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-passport-expiration"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Passport expiration date
              </label>
              <div className="md:flex-1">
                <input
                  id="register-passport-expiration"
                  data-testid="UI-register-passport-expiration"
                  type="date"
                  value={passportExpirationDate}
                  onChange={event => update("passportExpirationDate", event.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-birth-date"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Date of birth
              </label>
              <div className="md:flex-1">
                <input
                  id="register-birth-date"
                  data-testid="UI-register-birth-date"
                  type="date"
                  value={dateOfBirth}
                  onChange={event => update("dateOfBirth", event.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <span
                id="register-gender-label"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Gender
              </span>
              <div
                data-testid="UI-register-gender"
                role="radiogroup"
                aria-labelledby="register-gender-label"
                className="flex gap-6 md:flex-1"
              >
                <label className="inline-flex items-center gap-2 rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-700">
                  <input
                    type="radio"
                    name="register-gender"
                    value="Male"
                    checked={gender === "Male"}
                    onChange={() => update("gender", "Male")}
                  />
                  Male
                </label>
                <label className="inline-flex items-center gap-2 rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-700">
                  <input
                    type="radio"
                    name="register-gender"
                    value="Female"
                    checked={gender === "Female"}
                    onChange={() => update("gender", "Female")}
                  />
                  Female
                </label>
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-username"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Username
              </label>
              <div className="md:flex-1">
                <input
                  id="register-username"
                  data-testid="UI-register-username"
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={event => update("username", event.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-password"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Password
              </label>
              <div className="md:flex-1">
                <input
                  id="register-password"
                  data-testid="UI-register-password"
                  type="password"
                  autoComplete="new-password"
                  value={password}
                  onChange={event => update("password", event.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-confirm-password"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Confirm Password
              </label>
              <div className="md:flex-1">
                <input
                  id="register-confirm-password"
                  data-testid="UI-register-confirm-password"
                  type="password"
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={event => update("confirmPassword", event.target.value)}
                  className={inputClass}
                />
              </div>
            </div>

            <div className="flex flex-col gap-2 md:flex-row md:items-start">
              <label
                htmlFor="register-email"
                className="text-sm font-medium text-slate-700 md:w-48 md:shrink-0 md:pt-2 md:text-right"
              >
                <span aria-hidden="true" className="mr-1 text-red-600">*</span>
                Email address
              </label>
              <div className="md:flex-1">
                <input
                  id="register-email"
                  data-testid="UI-register-email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={event => update("email", event.target.value)}
                  className={inputClass}
                />
                <p className="mt-1 text-xs text-orange-600">
                  Related notifications will be sent to you via email.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 border-t border-slate-100 pt-5">
            <label className="inline-flex items-start gap-2 text-sm text-slate-700">
              <input
                data-testid="UI-register-agreement"
                type="checkbox"
                checked={agreed}
                onChange={event => update("agreed", event.target.checked)}
                className="mt-0.5"
              />
              <span>
                I have read and agree to abide by <a href="#" className="text-blue-700 hover:underline">Terms of Service</a>{" "}
                and <a href="#" className="text-blue-700 hover:underline">Privacy Policy</a> of 12306.cn.
              </span>
            </label>
          </div>

          {errorVisible ? (
            <div className="mt-5">
              <div
                data-testid="UI-register-error"
                role="alert"
                className="rounded-md border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-700"
              >
                {failureMessage.length > 0 ? failureMessage : "This username has already been used."}
              </div>
            </div>
          ) : null}

          <div className="mt-6 text-center">
            <button
              data-testid="UI-next-step"
              type="submit"
              className="rounded-md bg-orange-500 px-10 py-3 text-base font-semibold text-white transition-colors hover:bg-orange-600"
            >
              Next step
            </button>
          </div>
        </form>
      </main>

      <footer className="mt-6 bg-slate-100 py-10 text-center text-[11px] uppercase tracking-wide text-slate-500">
        <p className="mx-auto max-w-4xl px-6">
          COPYRIGHT©2008-2025 CHINA ACADEMY OF RAILWAY SCIENCES CORPORATION LIMITED， ALL RIGHTS RESERVED
        </p>
        <p className="mx-auto mt-3 max-w-4xl px-6">
          京公网安备 11010802038392号 | 京ICP备05020493号-4 | ICP证：京B2-20202537
        </p>
        <p className="mt-3">Privacy Policy | Cookie Statement</p>
      </footer>
    </div>
  );
}
