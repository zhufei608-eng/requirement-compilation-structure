import { FormEvent, useEffect, useState } from "react";
import { isPresentationTest, presentationData } from "../ui-runtime";

interface LoginFormState {
  username: string;
  password: string;
}

const INITIAL_FORM: LoginFormState = { username: "", password: "" };

const fieldClass =
  "w-full border-0 bg-transparent px-2 py-3 text-sm text-slate-900 outline-none placeholder:text-slate-400";

export function LoginPage() {
  const [form, setForm] = useState<LoginFormState>(INITIAL_FORM);
  const [errorMessage, setErrorMessage] = useState("");
  const [hasError, setHasError] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isPresentationTest("login")) return;
    setHasError(false);
    setErrorMessage("");
  }, []);

  const data = presentationData("login", {
    "login.username": form.username,
    "login.password": form.password,
    "login.errorMessage": errorMessage,
    "login.hasError": hasError,
  });

  const readString = (key: string): string => {
    const value = data[key];
    return typeof value === "string" ? value : "";
  };

  const username = readString("login.username");
  const password = readString("login.password");
  const failureMessage = readString("login.errorMessage");
  const errorVisible = data["login.hasError"] === true;

  const update = <K extends keyof LoginFormState>(key: K, value: LoginFormState[K]) => {
    setForm(previous => ({ ...previous, [key]: value }));
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (submitting) return;
    if (password.length === 0) return;
    if (isPresentationTest("login")) return;

    setHasError(false);
    setErrorMessage("");
    setSubmitting(true);

    try {
      const response = await fetch("/api/sessions", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        window.history.pushState({}, "", "/");
        window.dispatchEvent(new PopStateEvent("popstate"));
        return;
      }

      let message = "Invalid username or password.";
      try {
        const body: unknown = await response.json();
        if (typeof body === "object" && body !== null) {
          const error = (body as Record<string, unknown>).error;
          if (typeof error === "object" && error !== null) {
            const text = (error as Record<string, unknown>).message;
            if (typeof text === "string" && text.length > 0) message = text;
          }
        }
      } catch {
        // keep the generic message when the error body is not JSON
      }
      setHasError(true);
      setErrorMessage(message);
    } catch {
      setHasError(true);
      setErrorMessage("Login failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div data-testid="UI-login-page" className="min-h-screen bg-white text-slate-800">
      <header className="border-b border-slate-100 bg-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-4">
          <div className="flex items-center gap-3">
            <span
              aria-hidden="true"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-red-700 text-lg font-bold text-white"
            >
              中
            </span>
            <div className="leading-tight">
              <div className="text-xl font-bold tracking-tight text-slate-900">中国铁路12306</div>
              <div className="text-[11px] font-medium uppercase tracking-[0.18em] text-slate-500">
                12306 CHINA RAILWAY
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-sm">
            <a href="/login" className="font-medium text-slate-700 transition-colors hover:text-blue-700">
              Login
            </a>
            <a href="/register" className="font-medium text-slate-700 transition-colors hover:text-blue-700">
              Register
            </a>
            <span className="hidden items-center gap-1 text-slate-600 sm:inline-flex">
              My 12306 <span aria-hidden="true" className="text-[10px]">▼</span>
            </span>
            <span className="hidden items-center gap-1 text-slate-600 sm:inline-flex">
              简体中文 <span aria-hidden="true" className="text-[10px]">▼</span>
            </span>
            <span className="hidden items-center gap-1 text-slate-600 md:inline-flex">
              <span aria-hidden="true">☎</span> Contact us
            </span>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden bg-gradient-to-br from-sky-600 via-sky-700 to-emerald-800">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_20%_30%,rgba(255,255,255,0.5),transparent_45%),radial-gradient(circle_at_75%_70%,rgba(16,185,129,0.55),transparent_50%)]"
        />

        <div className="relative mx-auto flex max-w-7xl flex-col gap-10 px-6 pb-16 pt-10 lg:flex-row lg:items-start lg:justify-between">
          <div className="order-2 max-w-2xl space-y-3 text-[11px] leading-relaxed text-white/85 lg:order-1 lg:mt-4">
            <p>
              1. The 12306.cn website provides information query and ticket refund services 24 hours a day, and the
              ticket sales and endorsement services from 5:00 to 1:00 the next day (5:00 to 23:30 on Tuesday).
            </p>
            <p>
              2. For ticket endorsement and refund on the 12306.cn website, the endorsement should be no later than
              24:00 on the date shown on the ticket, the change of destination no later than 48 hours before
              departure, and the ticket refund should be no later than the train's departure.
            </p>
          </div>

          <div
            data-testid="UI-login-card"
            className="order-1 w-full max-w-md rounded-lg bg-white p-7 shadow-2xl ring-1 ring-black/5 lg:order-2"
          >
            <h1 data-testid="UI-login-title" className="text-2xl font-semibold text-slate-900">
              Login
            </h1>

            <form className="mt-5" onSubmit={handleSubmit} noValidate>
              <label htmlFor="login-username" className="sr-only">
                Email/Username/Mobile number
              </label>
              <div className="flex items-center gap-2 border-b border-slate-200 focus-within:border-blue-600">
                <span aria-hidden="true" className="text-slate-400">
                  👤
                </span>
                <input
                  id="login-username"
                  data-testid="UI-login-username"
                  type="text"
                  autoComplete="username"
                  placeholder="Email/Username/Mobile number"
                  value={username}
                  onChange={event => update("username", event.target.value)}
                  className={fieldClass}
                />
              </div>

              <label htmlFor="login-password" className="sr-only">
                Password
              </label>
              <div className="mt-2 flex items-center gap-2 border-b border-slate-200 focus-within:border-blue-600">
                <span aria-hidden="true" className="text-slate-400">
                  🔒
                </span>
                <input
                  id="login-password"
                  data-testid="UI-login-password"
                  type="password"
                  autoComplete="current-password"
                  placeholder="Password"
                  value={password}
                  onChange={event => update("password", event.target.value)}
                  className={fieldClass}
                />
              </div>

              <div className="mt-3 text-right">
                <a
                  data-testid="UI-login-forgot"
                  href="#"
                  className="text-xs text-blue-700 hover:underline"
                >
                  Forgot your password
                </a>
              </div>

              <button
                data-testid="UI-login-submit"
                type="submit"
                className="mt-5 w-full rounded-md bg-orange-500 px-6 py-3 text-base font-semibold uppercase tracking-wide text-white transition-colors hover:bg-orange-600"
              >
                LOGIN
              </button>

              {errorVisible ? (
                <div
                  data-testid="UI-login-error"
                  role="alert"
                  className="mt-4 rounded-md border border-red-300 bg-red-50 px-3 py-2 text-sm text-red-700"
                >
                  {failureMessage.length > 0 ? failureMessage : "Invalid username or password."}
                </div>
              ) : null}

              <div
                data-testid="UI-login-register-row"
                className="mt-5 flex flex-wrap items-center justify-center gap-1 text-sm text-slate-600"
              >
                <span data-testid="UI-login-register-prompt">No account yet?</span>
                <a
                  data-testid="UI-login-register-link"
                  href="/register"
                  className="text-blue-700 underline hover:text-blue-800"
                >
                  Register now !
                </a>
              </div>
            </form>
          </div>
        </div>

        <div className="relative flex justify-center pb-6" aria-hidden="true">
          <span className="h-2.5 w-2.5 rounded-full bg-white" />
        </div>
      </section>

      <footer className="bg-slate-100 py-10 text-center text-[11px] uppercase tracking-wide text-slate-500">
        <p className="mx-auto max-w-4xl px-6">
          COPYRIGHT©2008-2025 CHINA ACADEMY OF RAILWAY SCIENCES CORPORATION LIMITED, ALL RIGHTS RESERVED
        </p>
        <p className="mx-auto mt-3 max-w-4xl px-6">
          京公网安备 11010802038392号 | 京ICP备05020493号-4 | ICP证：京B2-20202537
        </p>
        <p className="mt-3">Privacy Policy | Cookie Statement</p>
      </footer>
    </div>
  );
}
