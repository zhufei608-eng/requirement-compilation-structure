import { useEffect, useState } from "react";
import { isPresentationTest, presentationData } from "../ui-runtime";

type SessionStatus = "loading" | "authenticated" | "signed_out";

interface SessionState {
  status: SessionStatus;
  username: string;
}

const INITIAL_SESSION: SessionState = { status: "loading", username: "" };

export function HomePage() {
  const [session, setSession] = useState<SessionState>(INITIAL_SESSION);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    if (isPresentationTest("home")) return;
    let active = true;

    async function resolveSession() {
      try {
        const response = await fetch("/api/session/current", {
          method: "GET",
          credentials: "include",
          headers: { Accept: "application/json" },
        });
        if (!active) return;
        if (!response.ok) {
          setSession({ status: "signed_out", username: "" });
          return;
        }
        const body: unknown = await response.json();
        if (!active) return;
        const record = typeof body === "object" && body !== null ? (body as Record<string, unknown>) : {};
        const username = typeof record.username === "string" ? record.username : "";
        if (record.authenticated === true && username.length > 0) {
          setSession({ status: "authenticated", username });
        } else {
          setSession({ status: "signed_out", username: "" });
        }
      } catch {
        if (active) setSession({ status: "signed_out", username: "" });
      }
    }

    void resolveSession();
    return () => {
      active = false;
    };
  }, []);

  async function handleLogout() {
    if (session.status !== "authenticated") return;
    if (loggingOut) return;
    setLoggingOut(true);
    try {
      const response = await fetch("/api/session/current", {
        method: "DELETE",
        credentials: "include",
        headers: { Accept: "application/json" },
      });
      if (response.status === 204) {
        setSession({ status: "signed_out", username: "" });
      }
    } catch {
      // Keep the authenticated display: the server-side session was not confirmed invalidated.
    } finally {
      setLoggingOut(false);
    }
  }

  const data = presentationData("home", {
    "session.status": session.status,
    "session.username": session.username,
  });
  const status = typeof data["session.status"] === "string" ? (data["session.status"] as string) : "";
  const username = typeof data["session.username"] === "string" ? (data["session.username"] as string) : "";
  const signedOut = status === "signed_out";
  const authenticated = status === "authenticated";

  return (
    <div data-testid="UI-home" className="min-h-screen bg-white text-slate-800">
      <header data-testid="UI-header" className="border-b border-slate-100 bg-white">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-4">
          <div className="flex items-center gap-3">
            <span
              aria-hidden="true"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-red-700 text-lg font-bold text-white"
            >
              中
            </span>
            <div className="leading-tight">
              <div data-testid="UI-brand" className="text-xl font-bold tracking-tight text-slate-900">
                中国铁路12306
              </div>
              <div className="text-[11px] font-medium uppercase tracking-[0.18em] text-slate-500">
                12306 CHINA RAILWAY
              </div>
            </div>
          </div>

          <div data-testid="UI-auth-nav" className="flex flex-wrap items-center gap-4 text-sm">
            {signedOut ? (
              <>
                <a
                  data-testid="UI-register-link"
                  href="/register"
                  className="font-medium text-slate-700 transition-colors hover:text-blue-700"
                >
                  Register
                </a>
                <a
                  data-testid="UI-login-link"
                  href="/login"
                  className="font-medium text-slate-700 transition-colors hover:text-blue-700"
                >
                  Login
                </a>
              </>
            ) : null}
            {authenticated ? (
              <>
                <span
                  data-testid="UI-username"
                  className="inline-flex min-h-6 min-w-4 items-center rounded px-2 text-sm font-semibold text-slate-900"
                >
                  {username}
                </span>
                <button
                  data-testid="UI-logout-button"
                  type="button"
                  onClick={() => void handleLogout()}
                  disabled={loggingOut}
                  className="rounded border border-slate-300 px-3 py-1 text-sm font-medium text-slate-700 transition-colors hover:border-blue-600 hover:text-blue-700"
                >
                  Logout
                </button>
              </>
            ) : null}
            <span className="hidden items-center gap-1 text-slate-600 sm:inline-flex">
              My 12306 <span aria-hidden="true" className="text-[10px]">▼</span>
            </span>
            <span className="hidden items-center gap-1 text-slate-600 sm:inline-flex">
              简体中文 <span aria-hidden="true" className="text-[10px]">▼</span>
            </span>
            <span className="hidden items-center gap-1 text-slate-600 md:inline-flex">
              <span aria-hidden="true">☎</span> Contact us
            </span>
          </div>
        </div>
      </header>

      <nav aria-label="Main navigation" className="bg-blue-700 text-white">
        <div className="mx-auto flex max-w-7xl items-center gap-8 px-6 py-3 text-sm font-medium">
          <span className="font-semibold">Home</span>
          <span className="flex items-center gap-1">
            Booking <span aria-hidden="true" className="text-[10px]">▼</span>
          </span>
          <span className="flex items-center gap-1">
            Travel guides <span aria-hidden="true" className="text-[10px]">▼</span>
          </span>
        </div>
      </nav>

      <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-800 to-orange-950">
        <div className="mx-auto flex min-h-[320px] max-w-7xl items-end px-6 pb-24 pt-16">
          <div className="flex gap-2 pb-4" aria-hidden="true">
            <span className="h-2.5 w-2.5 rounded-full bg-white" />
            <span className="h-2.5 w-2.5 rounded-full bg-white/50" />
            <span className="h-2.5 w-2.5 rounded-full bg-white/50" />
          </div>
        </div>
      </section>

      <div className="relative mx-auto -mt-20 max-w-6xl px-6">
        <div className="rounded-2xl bg-white p-6 shadow-xl ring-1 ring-slate-200">
          <p className="flex items-start gap-2 text-xs leading-relaxed text-slate-500">
            <span aria-hidden="true" className="mt-0.5">🕒</span>
            <span>
              The 12306.cn website provides information query and ticket refund services 24 hours a day, and the
              ticket sales and endorsement services from 5:00 to 1:00 the next day (5:00 to 23:30 on Tuesday).
            </span>
          </p>
          <div className="mt-5 flex flex-col items-stretch gap-4 md:flex-row md:items-end">
            <div className="flex-1">
              <div className="text-xs font-medium uppercase tracking-wide text-slate-400">From</div>
              <div className="mt-1 flex items-center gap-2 border-b border-slate-200 pb-2 text-lg font-semibold text-slate-900">
                <span aria-hidden="true" className="text-slate-400">📍</span>
                Beijing(北京)
              </div>
            </div>
            <span
              aria-hidden="true"
              className="hidden h-10 w-10 items-center justify-center rounded-full bg-orange-500 text-white md:flex"
            >
              ⇄
            </span>
            <div className="flex-1">
              <div className="text-xs font-medium uppercase tracking-wide text-slate-400">To</div>
              <div className="mt-1 flex items-center gap-2 border-b border-slate-200 pb-2 text-lg font-semibold text-slate-900">
                <span aria-hidden="true" className="text-slate-400">📍</span>
                Shanghai(上海)
              </div>
            </div>
            <div className="flex-1">
              <div className="text-xs font-medium uppercase tracking-wide text-slate-400">Date</div>
              <div className="mt-1 flex items-center gap-2 border-b border-slate-200 pb-2 text-lg font-semibold text-slate-900">
                <span aria-hidden="true" className="text-slate-400">📅</span>
                Fri, May 29
              </div>
            </div>
            <button
              type="button"
              className="rounded-md bg-orange-500 px-8 py-3 text-base font-semibold text-white transition-colors hover:bg-orange-600"
            >
              Search
            </button>
          </div>
          <div className="mt-5 flex items-center gap-2 text-sm text-slate-600">
            <span aria-hidden="true" className="inline-block h-4 w-4 rounded-sm border border-slate-400" />
            High-speed trains only
          </div>
        </div>
      </div>

      <section className="mx-auto max-w-6xl px-6 py-14">
        <h2 className="text-2xl font-semibold text-blue-700">Quick Guide</h2>
        <div className="mt-6 grid gap-8 md:grid-cols-2">
          <ul className="list-disc space-y-3 pl-5 text-sm text-slate-700">
            <li>What ID documents are accepted by 12306.cn English website?</li>
            <li>What services does 12306.cn English website provide?</li>
          </ul>
          <div>
            <ul className="list-disc space-y-3 pl-5 text-sm text-slate-700">
              <li>What is endorsement?</li>
              <li>What are the rules of ticket endorsement?</li>
            </ul>
            <span className="mt-4 inline-block text-sm font-medium text-blue-700">More&gt;</span>
          </div>
        </div>
      </section>

      <footer className="bg-slate-100 py-10 text-center text-[11px] uppercase tracking-wide text-slate-500">
        <p className="mx-auto max-w-4xl px-6">
          COPYRIGHT@2008-2025 CHINA ACADEMY OF RAILWAY SCIENCES CORPORATION LIMITED, ALL RIGHTS RESERVED
        </p>
        <p className="mx-auto mt-3 max-w-4xl px-6">
          京公网安备 11010802038392号 | 京ICP备05020493号-4 | ICP证: 京B2-20202537
        </p>
        <p className="mt-3">Privacy Policy | Cookie Statement</p>
      </footer>
    </div>
  );
}
