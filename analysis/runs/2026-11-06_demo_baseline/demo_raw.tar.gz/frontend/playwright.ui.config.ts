// Compiler-owned UI existence tests. No backend is started at this stage.
import { defineConfig } from "@playwright/test";

const port = Number(process.env.ARC_UI_PORT ?? "4173");
const baseURL = `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: "./tests/ui",
  outputDir: "./test-results/ui",
  workers: 1,
  retries: 0,
  forbidOnly: true,
  timeout: 20000,
  expect: { timeout: 4000 },
  reporter: "json",
  use: { baseURL, browserName: "chromium", headless: true,
    trace: "retain-on-failure", screenshot: "only-on-failure" },
  webServer: {
    command: `node ../node_modules/vite/bin/vite.js --host 127.0.0.1 --port ${port} --strictPort`,
    url: baseURL, reuseExistingServer: false, timeout: 600000,
  },
});
