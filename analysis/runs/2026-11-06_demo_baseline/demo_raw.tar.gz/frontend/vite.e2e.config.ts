import { defineConfig, mergeConfig } from "vite";
import base from "./vite.config";
export default mergeConfig(base, defineConfig({ server: { proxy: { "/api": process.env.ARC_BACKEND_URL! } } }));
