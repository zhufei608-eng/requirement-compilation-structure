// Every invocation owns a new database; no production database is reset.
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { createServer } from "node:net";
import { spawn, spawnSync } from "node:child_process";
const root = fileURLToPath(new URL("../../", import.meta.url));
async function freePort() {
  const server = createServer();
  await new Promise((resolve, reject) => { server.once("error", reject); server.listen(0, "127.0.0.1", resolve); });
  const port = server.address().port;
  await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  return port;
}
const directory = mkdtempSync(join(process.env.ARC_E2E_TEMP_ROOT ?? tmpdir(), "arc-e2e-"));
try {
  const backend = await freePort();
  let frontend = await freePort();
  while (frontend === backend) frontend = await freePort();
  const child = spawn(process.execPath, ["node_modules/@playwright/test/cli.js", "test",
    "--config", "frontend/playwright.e2e.config.ts", ...process.argv.slice(2)], {
    cwd: root, stdio: "inherit", env: { ...process.env, ARC_E2E_BACKEND_PORT: String(backend),
      ARC_E2E_FRONTEND_PORT: String(frontend), ARC_E2E_DB_FILE: join(directory, "app.db") },
  });
  const forward = signal => {
    if (process.platform === "win32" && child.pid)
      spawnSync("taskkill", ["/PID", String(child.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true });
    else child.kill(signal);
  };
  process.on("SIGINT", forward); process.on("SIGTERM", forward);
  try {
    process.exitCode = await new Promise((resolve, reject) => { child.once("error", reject); child.once("close", code => resolve(code ?? 1)); });
  } finally { process.off("SIGINT", forward); process.off("SIGTERM", forward); }
} finally { rmSync(directory, { recursive: true, force: true, maxRetries: 20, retryDelay: 100 }); }
