import { test } from "node:test";
import assert from "node:assert/strict";
import { createApiTest } from "./support/context.js";

const seededAccountId = "00000000-0000-4000-8000-000000000001";
const seededCredential = "taken-traveler-session-credential";

function countSessions(database: ReturnType<typeof createApiTest>["database"], accountId: string): number {
  const row = database
    .prepare('SELECT COUNT(*) AS total FROM "Session" WHERE "account_id" = ?')
    .get(accountId) as { total: number };
  return row.total;
}

function setCookieValues(response: Response): string[] {
  const headers = response.headers as Headers & { getSetCookie?: () => string[] };
  if (typeof headers.getSetCookie === "function") return headers.getSetCookie();
  const single = response.headers.get("set-cookie");
  return single ? [single] : [];
}

function sessionCredentialFrom(response: Response): string {
  const cookies = setCookieValues(response);
  const cookie = cookies.find((value) => value.trim().toLowerCase().startsWith("session="));
  assert.ok(cookie, "expected a session cookie in the response");
  assert.match(cookie, /HttpOnly/i);
  assert.match(cookie, /Path=\//i);
  const raw = cookie.slice(cookie.indexOf("=") + 1).split(";")[0].trim();
  assert.ok(raw.length > 0, "expected a nonempty session credential");
  return decodeURIComponent(raw);
}

async function login(baseURL: string, body: Record<string, unknown>): Promise<Response> {
  return fetch(new URL("/api/sessions", baseURL), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    redirect: "manual"
  });
}

test("POST /api/sessions logs in with correct credentials and creates a new session", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const passwordHashBefore = (
    database.prepare('SELECT "password_hash" AS hash FROM "Account" WHERE "id" = ?').get(seededAccountId) as {
      hash: string;
    }
  ).hash;
  assert.match(passwordHashBefore, /^scrypt\$[0-9a-f]{32}\$[0-9a-f]{128}$/);
  assert.notEqual(passwordHashBefore, "TakenSmoke!2026");
  const sessionsBefore = countSessions(database, seededAccountId);
  assert.equal(sessionsBefore, 1);

  const response = await login(baseURL, { username: "taken_traveler", password: "TakenSmoke!2026" });
  assert.equal(response.status, 200);
  const body = (await response.json()) as {
    authenticated: boolean;
    account: { id: string; username: string };
  };
  assert.equal(body.authenticated, true);
  assert.equal(body.account.id, seededAccountId);
  assert.equal(body.account.username, "taken_traveler");
  assert.equal(JSON.stringify(body).includes("TakenSmoke!2026"), false);

  const credential = sessionCredentialFrom(response);
  assert.notEqual(credential, seededCredential);

  const created = database
    .prepare('SELECT "id", "account_id" FROM "Session" WHERE "credential" = ?')
    .get(credential) as { id: string; account_id: string } | undefined;
  assert.ok(created, "expected the new session to be persisted");
  assert.equal(created.account_id, seededAccountId);
  assert.equal(countSessions(database, seededAccountId), sessionsBefore + 1);

  const existing = database
    .prepare('SELECT "account_id" FROM "Session" WHERE "credential" = ?')
    .get(seededCredential) as { account_id: string } | undefined;
  assert.equal(existing?.account_id, seededAccountId, "existing sessions must remain unchanged");

  const passwordHashAfter = (
    database.prepare('SELECT "password_hash" AS hash FROM "Account" WHERE "id" = ?').get(seededAccountId) as {
      hash: string;
    }
  ).hash;
  assert.equal(passwordHashAfter, passwordHashBefore, "login must not change the stored password hash");
});

test("POST /api/sessions rejects an incorrect password without creating a session", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const sessionsBefore = countSessions(database, seededAccountId);

  const response = await login(baseURL, { username: "taken_traveler", password: "WrongSmoke!2026" });
  assert.equal(response.status, 401);
  const body = (await response.json()) as { error: { code: string; message: string } };
  assert.equal(body.error.code, "invalid_credentials");
  assert.equal(typeof body.error.message, "string");
  assert.ok(body.error.message.length > 0);
  assert.equal(setCookieValues(response).length, 0, "no session cookie should be set");

  assert.equal(countSessions(database, seededAccountId), sessionsBefore);
  const existing = database
    .prepare('SELECT "id" FROM "Session" WHERE "credential" = ?')
    .get(seededCredential) as { id: string } | undefined;
  assert.ok(existing, "existing sessions must remain unchanged");
});

test("POST /api/sessions rejects an unknown username without creating a session", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const totalBefore = (database.prepare('SELECT COUNT(*) AS total FROM "Session"').get() as { total: number }).total;

  const response = await login(baseURL, { username: "missing_traveler", password: "TakenSmoke!2026" });
  assert.equal(response.status, 401);
  const body = (await response.json()) as { error: { code: string } };
  assert.equal(body.error.code, "invalid_credentials");
  assert.equal(setCookieValues(response).length, 0);

  const totalAfter = (database.prepare('SELECT COUNT(*) AS total FROM "Session"').get() as { total: number }).total;
  assert.equal(totalAfter, totalBefore);
  const accountCount = (
    database.prepare('SELECT COUNT(*) AS total FROM "Account" WHERE "username" = ?').get("missing_traveler") as {
      total: number;
    }
  ).total;
  assert.equal(accountCount, 0, "login must not create accounts");
});

test("POST /api/sessions compares usernames case-sensitively", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const sessionsBefore = countSessions(database, seededAccountId);

  const response = await login(baseURL, { username: "TAKEN_TRAVELER", password: "TakenSmoke!2026" });
  assert.equal(response.status, 401);
  const body = (await response.json()) as { error: { code: string } };
  assert.equal(body.error.code, "invalid_credentials");
  assert.equal(setCookieValues(response).length, 0);
  assert.equal(countSessions(database, seededAccountId), sessionsBefore);
});
