import { test } from "node:test";
import assert from "node:assert/strict";
import { createApiTest, fixturePasswordHash } from "./support/context.js";

function snapshot(database: ReturnType<typeof createApiTest>["database"]) {
  return {
    accounts: database.prepare('SELECT * FROM "Account" ORDER BY "id"').all(),
    sessions: database.prepare('SELECT * FROM "Session" ORDER BY "id"').all()
  };
}

async function currentSession(baseURL: string, cookie?: string) {
  const headers: Record<string, string> = {};
  if (cookie !== undefined) headers.cookie = cookie;
  return fetch(new URL("/api/session/current", baseURL), {
    method: "GET",
    headers,
    redirect: "manual"
  });
}

test("resolves the existing session to the exact account username", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const before = snapshot(database);

  const response = await currentSession(baseURL, "session=taken-traveler-session-credential");
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("set-cookie"), null);
  const body = (await response.json()) as Record<string, unknown>;
  assert.equal(body.authenticated, true);
  assert.equal(body.username, "taken_traveler");

  assert.deepEqual(snapshot(database), before);
});

test("reports signed out when no session credential is supplied", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const before = snapshot(database);

  const response = await currentSession(baseURL);
  assert.equal(response.status, 200);
  const body = (await response.json()) as Record<string, unknown>;
  assert.equal(body.authenticated, false);
  assert.equal(body.username, null);

  assert.deepEqual(snapshot(database), before);
});

test("reports signed out for an unrecognized session credential", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const before = snapshot(database);

  const response = await currentSession(baseURL, "session=does-not-match-any-session");
  assert.equal(response.status, 200);
  const body = (await response.json()) as Record<string, unknown>;
  assert.equal(body.authenticated, false);
  assert.equal(body.username, null);

  assert.deepEqual(snapshot(database), before);
});

test("resolves a differently named account from its own session credential", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const accountId = "11111111-1111-4111-8111-111111111111";
  database.prepare(
    'INSERT INTO "Account" ("id", "username", "nationality", "name", "passport_number", "passport_expiration_date", "date_of_birth", "gender", "email", "password_hash", "agreement_consent") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(
    accountId,
    "second_traveler",
    "China",
    "Second Traveler",
    "P00000002",
    "2031-02-02",
    "1991-02-02",
    "Female",
    "second_traveler@example.com",
    fixturePasswordHash("SecondSmoke!2026"),
    1
  );
  database.prepare('INSERT INTO "Session" ("id", "account_id", "credential") VALUES (?, ?, ?)').run(
    "11111111-1111-4111-8111-111111111102",
    accountId,
    "second-traveler-session-credential"
  );

  const before = snapshot(database);
  const response = await currentSession(baseURL, "session=second-traveler-session-credential");
  assert.equal(response.status, 200);
  const body = (await response.json()) as Record<string, unknown>;
  assert.equal(body.authenticated, true);
  assert.equal(body.username, "second_traveler");

  assert.deepEqual(snapshot(database), before);
});
