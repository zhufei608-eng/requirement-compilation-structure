import { test } from "node:test";
import assert from "node:assert/strict";
import { createApiTest } from "./support/context.js";

function snapshot(database: ReturnType<typeof createApiTest>["database"]) {
  return {
    accounts: database.prepare('SELECT * FROM "Account" ORDER BY "id"').all(),
    sessions: database.prepare('SELECT * FROM "Session" ORDER BY "id"').all()
  };
}

async function register(baseURL: string, body: Record<string, unknown>) {
  return fetch(new URL("/api/accounts", baseURL), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    redirect: "manual"
  });
}

function cookieValue(setCookies: string[], name: string): string | null {
  for (const cookie of setCookies) {
    const first = cookie.split(";")[0].trim();
    const eq = first.indexOf("=");
    if (eq === -1) continue;
    if (first.slice(0, eq).trim() !== name) continue;
    return first.slice(eq + 1).trim();
  }
  return null;
}

function validRegistration(username: string) {
  return {
    nationality: "China",
    name: "New Traveler",
    passportNumber: "P99990001",
    passportExpirationDate: "2032-03-04",
    dateOfBirth: "1992-04-05",
    gender: "Female",
    username,
    password: "FreshSmoke!2026",
    confirmPassword: "FreshSmoke!2026",
    email: "new_traveler@example.com",
    agreementConsent: true
  };
}

test("registers a new account, stores hashed password, and issues a session cookie", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const payload = validRegistration("fresh_traveler");

  const response = await register(baseURL, payload);
  assert.equal(response.status, 201);

  const setCookies = response.headers.getSetCookie();
  assert.ok(setCookies.length >= 1, "expected a Set-Cookie header");
  const sessionCookie = setCookies.find((c) => c.split(";")[0].trim().startsWith("session="));
  assert.ok(sessionCookie, "expected a 'session' cookie");
  assert.match(sessionCookie!, /HttpOnly/i);
  const credential = cookieValue(setCookies, "session");
  assert.ok(credential && credential.length > 0, "expected a non-empty session credential");

  const body = (await response.json()) as { account: { id: string; username: string } };
  assert.equal(body.account.username, "fresh_traveler");
  assert.equal(typeof body.account.id, "string");
  assert.equal(JSON.stringify(body).includes("FreshSmoke!2026"), false);

  const account = database
    .prepare('SELECT * FROM "Account" WHERE "username" = ?')
    .get("fresh_traveler") as Record<string, unknown> | undefined;
  assert.ok(account, "account should be persisted");
  assert.equal(account!.id, body.account.id);
  assert.equal(account!.nationality, "China");
  assert.equal(account!.name, "New Traveler");
  assert.equal(account!.passport_number, "P99990001");
  assert.equal(account!.passport_expiration_date, "2032-03-04");
  assert.equal(account!.date_of_birth, "1992-04-05");
  assert.equal(account!.gender, "Female");
  assert.equal(account!.email, "new_traveler@example.com");
  assert.equal(account!.agreement_consent, 1);
  assert.notEqual(account!.password_hash, "FreshSmoke!2026");
  assert.equal(String(account!.password_hash).includes("FreshSmoke!2026"), false);

  const session = database
    .prepare('SELECT * FROM "Session" WHERE "credential" = ?')
    .get(credential!) as Record<string, unknown> | undefined;
  assert.ok(session, "session should be persisted with the issued credential");
  assert.equal(session!.account_id, body.account.id);
});

test("rejects a duplicate username without creating an account or session", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const before = snapshot(database);

  const response = await register(baseURL, validRegistration("taken_traveler"));
  assert.equal(response.status, 409);
  assert.equal(response.headers.getSetCookie().length, 0);
  const body = (await response.json()) as { error: { code: string } };
  assert.equal(body.error.code, "username_already_used");

  assert.deepEqual(snapshot(database), before);
});

test("rejects mismatched passwords without creating an account or session", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const before = snapshot(database);
  const payload = { ...validRegistration("mismatch_traveler"), confirmPassword: "Different!2026" };

  const response = await register(baseURL, payload);
  assert.equal(response.status, 400);
  assert.equal(response.headers.getSetCookie().length, 0);
  const body = (await response.json()) as { error: { code: string } };
  assert.equal(body.error.code, "passwords_do_not_match");

  assert.deepEqual(snapshot(database), before);
});

test("rejects registration without agreement consent", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const before = snapshot(database);
  const payload = { ...validRegistration("no_consent_traveler"), agreementConsent: false };

  const response = await register(baseURL, payload);
  assert.equal(response.status, 400);
  assert.equal(response.headers.getSetCookie().length, 0);
  const body = (await response.json()) as { error: { code: string } };
  assert.equal(body.error.code, "agreement_consent_required");

  assert.deepEqual(snapshot(database), before);
});

test("rejects incomplete or invalid registration fields", async (t) => {
  const { database, baseURL } = createApiTest(t);
  const before = snapshot(database);

  const { email: _email, ...missingEmail } = validRegistration("invalid_traveler");
  const invalidGender = { ...validRegistration("invalid_gender_traveler"), gender: "Other" };

  for (const payload of [missingEmail, invalidGender]) {
    const response = await register(baseURL, payload as Record<string, unknown>);
    assert.equal(response.status, 400);
    assert.equal(response.headers.getSetCookie().length, 0);
    const body = (await response.json()) as { error: { code: string } };
    assert.equal(body.error.code, "invalid_registration");
  }

  assert.deepEqual(snapshot(database), before);
});
