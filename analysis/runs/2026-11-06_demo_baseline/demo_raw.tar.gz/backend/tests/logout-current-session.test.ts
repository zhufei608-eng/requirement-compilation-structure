import { test } from "node:test";
import assert from "node:assert/strict";
import { createApiTest } from "./support/context.js";

const SESSION_COOKIE = "taken-traveler-session-credential";
const SECOND_SESSION_ID = "11111111-1111-4111-8111-111111111111";
const SECOND_SESSION_CREDENTIAL = "other-session-credential";

function findSessionCookie(response: Response): string {
  const found = response.headers
    .getSetCookie()
    .find((cookie) => cookie.trim().toLowerCase().startsWith("session="));
  assert.ok(found, "expected a Set-Cookie header for the session cookie");
  return found!;
}

function assertClearedCookie(cookie: string): void {
  const pair = cookie.split(";")[0].trim();
  assert.equal(pair, "session=");
  assert.match(cookie, /HttpOnly/i);
  assert.match(cookie, /Max-Age=0/i);
  const expires = /Expires=([^;]+)/i.exec(cookie);
  assert.ok(expires, "expected an Expires attribute on the cleared cookie");
  const timestamp = Date.parse(expires![1].trim());
  assert.ok(Number.isFinite(timestamp), "expected a parsable Expires attribute");
  assert.ok(timestamp < Date.now(), "expected the Expires attribute to be in the past");
}

test("DELETE /api/session/current invalidates the matching session and clears the cookie", async (t) => {
  const { database, baseURL } = createApiTest(t);

  const accountBefore = database
    .prepare('SELECT * FROM "Account" WHERE "username" = ?')
    .get("taken_traveler") as Record<string, unknown>;
  const otherSessionsBefore = database
    .prepare('SELECT COUNT(*) AS count FROM "Session" WHERE "credential" <> ?')
    .get(SESSION_COOKIE) as { count: number };

  database
    .prepare('INSERT INTO "Session" ("id", "account_id", "credential") VALUES (?, ?, ?)')
    .run(SECOND_SESSION_ID, accountBefore.id, SECOND_SESSION_CREDENTIAL);

  const response = await fetch(new URL("/api/session/current", baseURL), {
    method: "DELETE",
    headers: { cookie: `session=${SESSION_COOKIE}` },
    redirect: "manual"
  });

  assert.equal(response.status, 204);
  const bodyText = await response.text();
  assert.equal(bodyText, "");
  assert.ok(!bodyText.includes(SESSION_COOKIE), "credential must not appear in the body");
  assertClearedCookie(findSessionCookie(response));

  const matching = database
    .prepare('SELECT COUNT(*) AS count FROM "Session" WHERE "credential" = ?')
    .get(SESSION_COOKIE) as { count: number };
  assert.equal(matching.count, 0);

  const otherStillPresent = database
    .prepare('SELECT COUNT(*) AS count FROM "Session" WHERE "id" = ?')
    .get(SECOND_SESSION_ID) as { count: number };
  assert.equal(otherStillPresent.count, 1);

  const otherSessionsAfter = database
    .prepare('SELECT COUNT(*) AS count FROM "Session" WHERE "id" <> ?')
    .get(SECOND_SESSION_ID) as { count: number };
  assert.equal(otherSessionsAfter.count, otherSessionsBefore.count);

  const accountAfter = database
    .prepare('SELECT * FROM "Account" WHERE "username" = ?')
    .get("taken_traveler") as Record<string, unknown>;
  assert.deepEqual(accountAfter, accountBefore);
});

test("after logout the old session credential no longer resolves as authenticated", async (t) => {
  const { database, baseURL } = createApiTest(t);

  const logout = await fetch(new URL("/api/session/current", baseURL), {
    method: "DELETE",
    headers: { cookie: `session=${SESSION_COOKIE}` },
    redirect: "manual"
  });
  assert.equal(logout.status, 204);

  const remaining = database
    .prepare('SELECT COUNT(*) AS count FROM "Session" WHERE "credential" = ?')
    .get(SESSION_COOKIE) as { count: number };
  assert.equal(remaining.count, 0);

  const current = await fetch(new URL("/api/session/current", baseURL), {
    method: "GET",
    headers: { cookie: `session=${SESSION_COOKIE}` },
    redirect: "manual"
  });
  assert.equal(current.status, 200);
  const body = await current.json();
  assert.equal(body.authenticated, false);
  assert.equal(body.username, null);
});

test("DELETE /api/session/current with an unknown credential is idempotent", async (t) => {
  const { database, baseURL } = createApiTest(t);

  const sessionsBefore = database
    .prepare('SELECT COUNT(*) AS count FROM "Session"')
    .get() as { count: number };
  const accountsBefore = database
    .prepare('SELECT * FROM "Account" ORDER BY "id"')
    .all();

  const response = await fetch(new URL("/api/session/current", baseURL), {
    method: "DELETE",
    headers: { cookie: "session=does-not-exist-credential" },
    redirect: "manual"
  });

  assert.equal(response.status, 204);
  assert.equal(await response.text(), "");
  assertClearedCookie(findSessionCookie(response));

  const sessionsAfter = database
    .prepare('SELECT COUNT(*) AS count FROM "Session"')
    .get() as { count: number };
  assert.equal(sessionsAfter.count, sessionsBefore.count);

  const preserved = database
    .prepare('SELECT COUNT(*) AS count FROM "Session" WHERE "credential" = ?')
    .get(SESSION_COOKIE) as { count: number };
  assert.equal(preserved.count, 1);

  const accountsAfter = database
    .prepare('SELECT * FROM "Account" ORDER BY "id"')
    .all();
  assert.deepEqual(accountsAfter, accountsBefore);
});

test("DELETE /api/session/current without a session cookie still clears the cookie", async (t) => {
  const { database, baseURL } = createApiTest(t);

  const sessionsBefore = database
    .prepare('SELECT COUNT(*) AS count FROM "Session"')
    .get() as { count: number };

  const response = await fetch(new URL("/api/session/current", baseURL), {
    method: "DELETE",
    redirect: "manual"
  });

  assert.equal(response.status, 204);
  assert.equal(await response.text(), "");
  assertClearedCookie(findSessionCookie(response));

  const sessionsAfter = database
    .prepare('SELECT COUNT(*) AS count FROM "Session"')
    .get() as { count: number };
  assert.equal(sessionsAfter.count, sessionsBefore.count);
});
