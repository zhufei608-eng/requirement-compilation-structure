-- Prerequisite rows for Session; extended incrementally by requirement.

-- REQ-1: valid existing session for taken_traveler, used to display the authenticated username.
INSERT INTO "Session" ("id", "account_id", "credential")
SELECT
  '00000000-0000-4000-8000-000000000101',
  a."id",
  'taken-traveler-session-credential'
FROM "Account" a
WHERE a."username" = 'taken_traveler'
  AND NOT EXISTS (
    SELECT 1 FROM "Session" WHERE "credential" = 'taken-traveler-session-credential'
  );
