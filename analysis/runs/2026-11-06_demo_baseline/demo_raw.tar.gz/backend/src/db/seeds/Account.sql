-- Prerequisite rows for Account; extended incrementally by requirement.

-- REQ-1: pre-existing account whose display is restored from an existing session.
INSERT INTO "Account" (
  "id", "username", "nationality", "name", "passport_number",
  "passport_expiration_date", "date_of_birth", "gender", "email",
  "password_hash", "agreement_consent"
)
SELECT
  '00000000-0000-4000-8000-000000000001',
  'taken_traveler',
  'China',
  'Taken Traveler',
  'P00000001',
  '2030-01-01',
  '1990-01-01',
  'Male',
  'taken_traveler@example.com',
  -- REQ-3: login must be testable with the exact pre-existing credential.
  seed_password_hash('TakenSmoke!2026'),
  1
WHERE NOT EXISTS (
  SELECT 1 FROM "Account" WHERE "username" = 'taken_traveler'
);
