-- An existing authentication session that can be resolved from a browser-supplied session credential to determine the current account.
CREATE TABLE IF NOT EXISTS "Session" (
  "id" TEXT NOT NULL PRIMARY KEY UNIQUE,
  "account_id" TEXT NOT NULL REFERENCES "Account" ("id"),
  "credential" TEXT NOT NULL UNIQUE
);
