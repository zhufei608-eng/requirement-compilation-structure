-- A registered user account whose username is displayed on the home page when a valid existing session is resolved.
-- Application code is responsible for hashing the plaintext password before storing password_hash;
-- plaintext passwords must never be persisted in this column.
-- Application code also enforces that agreement_consent is true for registration to succeed.
CREATE TABLE IF NOT EXISTS "Account" (
  "id" TEXT NOT NULL PRIMARY KEY UNIQUE,
  "username" TEXT NOT NULL UNIQUE,
  "nationality" TEXT NOT NULL DEFAULT 'China',
  "name" TEXT NOT NULL,
  "passport_number" TEXT NOT NULL,
  "passport_expiration_date" TEXT NOT NULL,
  "date_of_birth" TEXT NOT NULL,
  "gender" TEXT NOT NULL CHECK ("gender" IN ('Male', 'Female')),
  "email" TEXT NOT NULL,
  "password_hash" TEXT NOT NULL,
  "agreement_consent" INTEGER NOT NULL CHECK ("agreement_consent" IN (0, 1))
);
