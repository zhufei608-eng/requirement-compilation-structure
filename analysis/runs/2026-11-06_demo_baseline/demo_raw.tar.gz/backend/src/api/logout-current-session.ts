import type { ApiRequest, ApiResponse } from "./types.js";
import type Database from "better-sqlite3";

const SESSION_COOKIE = "session";
const CLEARED_COOKIE =
  "session=; Path=/; HttpOnly; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT";

function readCookie(header: string | undefined, name: string): string | null {
  if (!header) return null;
  for (const part of header.split(";")) {
    const separator = part.indexOf("=");
    if (separator < 0) continue;
    const key = part.slice(0, separator).trim();
    if (key !== name) continue;
    const value = part.slice(separator + 1).trim();
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  }
  return null;
}

export async function handle(
  request: ApiRequest,
  connection: Database.Database
): Promise<ApiResponse> {
  const credential = readCookie(request.headers.cookie, SESSION_COOKIE);

  if (credential) {
    connection
      .prepare('DELETE FROM "Session" WHERE "credential" = ?')
      .run(credential);
  }

  return {
    status: 204,
    body: {},
    headers: { "set-cookie": CLEARED_COOKIE }
  };
}
