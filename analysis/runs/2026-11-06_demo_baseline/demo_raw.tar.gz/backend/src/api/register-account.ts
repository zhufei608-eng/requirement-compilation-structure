import type Database from "better-sqlite3";
import { randomBytes, randomUUID, scryptSync } from "node:crypto";
import type { ApiRequest, ApiResponse } from "./types.js";

interface Registration {
  nationality: string;
  name: string;
  passportNumber: string;
  passportExpirationDate: string;
  dateOfBirth: string;
  gender: "Male" | "Female";
  username: string;
  password: string;
  confirmPassword: string;
  email: string;
  agreementConsent: true;
}

const registrationKeys = new Set([
  "nationality",
  "name",
  "passportNumber",
  "passportExpirationDate",
  "dateOfBirth",
  "gender",
  "username",
  "password",
  "confirmPassword",
  "email",
  "agreementConsent"
]);

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isNonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.length > 0;
}

function isValidDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split("-").map((part) => Number(part));
  const date = new Date(Date.UTC(year, month - 1, day));
  return (
    date.getUTCFullYear() === year &&
    date.getUTCMonth() === month - 1 &&
    date.getUTCDate() === day
  );
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function readRegistration(body: unknown): Registration | null {
  if (!isPlainObject(body)) return null;
  if (Object.keys(body).some((key) => !registrationKeys.has(key))) return null;

  const {
    nationality,
    name,
    passportNumber,
    passportExpirationDate,
    dateOfBirth,
    gender,
    username,
    password,
    confirmPassword,
    email,
    agreementConsent
  } = body;

  if (
    !isNonEmptyString(nationality) ||
    !isNonEmptyString(name) ||
    !isNonEmptyString(passportNumber) ||
    !isNonEmptyString(passportExpirationDate) ||
    !isValidDate(passportExpirationDate) ||
    !isNonEmptyString(dateOfBirth) ||
    !isValidDate(dateOfBirth) ||
    (gender !== "Male" && gender !== "Female") ||
    !isNonEmptyString(username) ||
    !isNonEmptyString(password) ||
    !isNonEmptyString(confirmPassword) ||
    !isNonEmptyString(email) ||
    !isValidEmail(email) ||
    typeof agreementConsent !== "boolean"
  ) {
    return null;
  }

  return {
    nationality,
    name,
    passportNumber,
    passportExpirationDate,
    dateOfBirth,
    gender,
    username,
    password,
    confirmPassword,
    email,
    agreementConsent: agreementConsent as true
  };
}

function passwordHash(password: string): string {
  const salt = randomBytes(16);
  const digest = scryptSync(password, salt, 64);
  return `scrypt$${salt.toString("hex")}$${digest.toString("hex")}`;
}

export async function handle(request: ApiRequest, connection: Database.Database): Promise<ApiResponse> {
  const registration = readRegistration(request.body);
  if (!registration) {
    return {
      status: 400,
      body: { error: { code: "invalid_registration", message: "Registration details are incomplete or invalid." } }
    };
  }

  if (registration.password !== registration.confirmPassword) {
    return {
      status: 400,
      body: { error: { code: "passwords_do_not_match", message: "Password and confirmation password must match." } }
    };
  }

  if (registration.agreementConsent !== true) {
    return {
      status: 400,
      body: { error: { code: "agreement_consent_required", message: "Agreement consent is required to register." } }
    };
  }

  const accountId = randomUUID();
  const sessionId = randomUUID();
  const credential = randomUUID();
  const hash = passwordHash(registration.password);

  const createAccount = connection.transaction((): boolean => {
    const existing = connection
      .prepare('SELECT "id" FROM "Account" WHERE "username" = ?')
      .get(registration.username) as { id: string } | undefined;
    if (existing) return false;

    connection
      .prepare(
        'INSERT INTO "Account" ("id", "username", "nationality", "name", "passport_number", "passport_expiration_date", "date_of_birth", "gender", "email", "password_hash", "agreement_consent") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)'
      )
      .run(
        accountId,
        registration.username,
        registration.nationality,
        registration.name,
        registration.passportNumber,
        registration.passportExpirationDate,
        registration.dateOfBirth,
        registration.gender,
        registration.email,
        hash
      );

    connection
      .prepare('INSERT INTO "Session" ("id", "account_id", "credential") VALUES (?, ?, ?)')
      .run(sessionId, accountId, credential);

    return true;
  });

  if (!createAccount()) {
    return {
      status: 409,
      body: { error: { code: "username_already_used", message: "The requested username is already in use." } }
    };
  }

  return {
    status: 201,
    body: { account: { id: accountId, username: registration.username } },
    headers: {
      "set-cookie": `session=${encodeURIComponent(credential)}; Path=/; HttpOnly; SameSite=Lax`
    }
  };
}
