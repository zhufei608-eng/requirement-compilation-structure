import type Database from "better-sqlite3";
import { randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import type { ApiRequest, ApiResponse } from "./types.js";

interface LoginCredentials {
  username: string;
  password: string;
}

const loginKeys = new Set(["username", "password"]);

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function readCredentials(body: unknown): LoginCredentials | null {
  if (!isPlainObject(body)) return null;
  if (Object.keys(body).some((key) => !loginKeys.has(key))) return null;

  const { username, password } = body;
  if (typeof username !== "string" || typeof password !== "string" || password.length === 0) return null;
  return { username, password };
}

function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;

  const [, saltHex, digestHex] = parts;
  if (!/^[0-9a-f]+$/i.test(saltHex) || saltHex.length % 2 !== 0) return false;
  if (!/^[0-9a-f]+$/i.test(digestHex) || digestHex.length % 2 !== 0 || digestHex.length === 0) return false;

  try {
    const expected = Buffer.from(digestHex, "hex");
    const actual = scryptSync(password, Buffer.from(saltHex, "hex"), expected.length);
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

function invalidCredentials(): ApiResponse {
  return {
    status: 401,
    body: {
      error: {
        code: "invalid_credentials",
        message: "The username or password is incorrect."
      }
    }
  };
}

export async function handle(request: ApiRequest, connection: Database.Database): Promise<ApiResponse> {
  const credentials = readCredentials(request.body);
  if (!credentials) return invalidCredentials();

  const account = connection
    .prepare('SELECT "id", "username", "password_hash" FROM "Account" WHERE "username" = ?')
    .get(credentials.username) as { id: string; username: string; password_hash: string } | undefined;

  if (!account || !verifyPassword(credentials.password, account.password_hash)) {
    return invalidCredentials();
  }

  const sessionId = randomUUID();
  const credential = randomUUID();

  connection
    .prepare('INSERT INTO "Session" ("id", "account_id", "credential") VALUES (?, ?, ?)')
    .run(sessionId, account.id, credential);

  return {
    status: 200,
    body: { authenticated: true, account: { id: account.id, username: account.username } },
    headers: {
      "set-cookie": `session=${encodeURIComponent(credential)}; Path=/; HttpOnly; SameSite=Lax`
    }
  };
}
