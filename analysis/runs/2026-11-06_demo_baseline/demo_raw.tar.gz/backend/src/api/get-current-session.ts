import type Database from "better-sqlite3";
import type { ApiRequest, ApiResponse } from "./types.js";

function readSessionCookie(cookieHeader: string | undefined): string | null {
  if (!cookieHeader) return null;
  for (const part of cookieHeader.split(";")) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    const eq = trimmed.indexOf("=");
    if (eq === -1) continue;
    const name = trimmed.slice(0, eq).trim();
    if (name !== "session") continue;
    const value = trimmed.slice(eq + 1).trim();
    if (!value) return null;
    try {
      return decodeURIComponent(value);
    } catch {
      return value;
    }
  }
  return null;
}

export async function handle(request: ApiRequest, connection: Database.Database): Promise<ApiResponse> {
  const credential = readSessionCookie(request.headers.cookie);
  if (!credential) {
    return { status: 200, body: { authenticated: false, username: null } };
  }

  const row = connection
    .prepare(
      'SELECT "Account"."username" AS username FROM "Session" JOIN "Account" ON "Account"."id" = "Session"."account_id" WHERE "Session"."credential" = ?'
    )
    .get(credential) as { username: string } | undefined;

  if (!row) {
    return { status: 200, body: { authenticated: false, username: null } };
  }

  return { status: 200, body: { authenticated: true, username: row.username } };
}
