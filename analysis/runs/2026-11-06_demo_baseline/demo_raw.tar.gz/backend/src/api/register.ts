import type { Express } from "express";
import type Database from "better-sqlite3";
import { handle as handleGetCurrentSession } from "./get-current-session.js";
import { handle as handleRegisterAccount } from "./register-account.js";
import { handle as handleLoginAccount } from "./login-account.js";
import { handle as handleLogoutCurrentSession } from "./logout-current-session.js";

// API implementation tasks maintain this registry and preserve existing routes.
export function registerApis(app: Express, connection: Database.Database): void {
  app.get("/api/session/current", async (req, res, next) => {
    try {
      const response = await handleGetCurrentSession(
        {
          params: req.params as Record<string, string>,
          query: req.query as Record<string, unknown>,
          body: (req.body ?? {}) as Record<string, unknown>,
          headers: req.headers as Record<string, string | undefined>
        },
        connection
      );
      if (response.headers) {
        for (const [name, value] of Object.entries(response.headers)) res.setHeader(name, value);
      }
      res.status(response.status).json(response.body);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/accounts", async (req, res, next) => {
    try {
      const response = await handleRegisterAccount(
        {
          params: req.params as Record<string, string>,
          query: req.query as Record<string, unknown>,
          body: (req.body ?? {}) as Record<string, unknown>,
          headers: req.headers as Record<string, string | undefined>
        },
        connection
      );
      if (response.headers) {
        for (const [name, value] of Object.entries(response.headers)) res.setHeader(name, value);
      }
      res.status(response.status).json(response.body);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/session/current", async (req, res, next) => {
    try {
      const response = await handleLogoutCurrentSession(
        {
          params: req.params as Record<string, string>,
          query: req.query as Record<string, unknown>,
          body: (req.body ?? {}) as Record<string, unknown>,
          headers: req.headers as Record<string, string | undefined>
        },
        connection
      );
      if (response.headers) {
        for (const [name, value] of Object.entries(response.headers)) res.setHeader(name, value);
      }
      res.status(response.status).json(response.body);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/sessions", async (req, res, next) => {
    try {
      const response = await handleLoginAccount(
        {
          params: req.params as Record<string, string>,
          query: req.query as Record<string, unknown>,
          body: (req.body ?? {}) as Record<string, unknown>,
          headers: req.headers as Record<string, string | undefined>
        },
        connection
      );
      if (response.headers) {
        for (const [name, value] of Object.entries(response.headers)) res.setHeader(name, value);
      }
      res.status(response.status).json(response.body);
    } catch (error) {
      next(error);
    }
  });
}
